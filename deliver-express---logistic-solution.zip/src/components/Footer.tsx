import { Truck, Phone, MessageSquare, Mail, MapPin, ArrowUp, Clock } from 'lucide-react';
import { BUSINESS_INFO, VEHICLES, SERVICES } from '../data/logisticsData';

export default function Footer() {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-slate-950 text-slate-400 text-xs border-t border-slate-800 pt-16 pb-24 lg:pb-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 pb-12 border-b border-slate-800/80">
          
          {/* Col 1: Brand Info */}
          <div className="lg:col-span-4 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-orange-600 flex items-center justify-center text-white shadow-md">
                <Truck className="w-6 h-6 stroke-[2.2]" />
              </div>
              <div>
                <span className="text-xl font-black text-white tracking-tight block font-heading">
                  DELIVER <span className="text-orange-500">EXPRESS</span>
                </span>
                <span className="text-[10px] font-bold uppercase tracking-widest text-slate-400 block">
                  Logistic Solution • Delhi NCR
                </span>
              </div>
            </div>

            <p className="text-slate-400 leading-relaxed text-xs max-w-sm">
              Deliver Express is your premier cargo and logistics partner across Delhi NCR. Offering Per-Kg Transport (Delhi → Jaipur at ₹9/kg next day delivery), on-demand freight, Fixed Monthly Basis Dedicated Commercial Vehicles, and Full/Part Truck Loading (FTL/PTL).
            </p>

            <div className="flex items-center gap-2 pt-2">
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-slate-900 border border-slate-800 text-orange-400 text-[11px] font-semibold">
                <Clock className="w-3.5 h-3.5" /> 24/7 Dispatch Fleet
              </span>
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-slate-900 border border-slate-800 text-green-400 text-[11px] font-semibold">
                Delhi NCR Permits
              </span>
            </div>
          </div>

          {/* Col 2: Services */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="text-sm font-bold text-white uppercase tracking-wider font-heading">
              Our Services
            </h4>
            <ul className="space-y-2">
              {SERVICES.map((s) => (
                <li key={s.id}>
                  <a
                    href="#services"
                    className="hover:text-orange-400 transition-colors flex items-center gap-1.5"
                  >
                    <span className="text-orange-500">•</span>
                    <span>{s.title}</span>
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Col 3: Commercial Fleet */}
          <div className="lg:col-span-2 space-y-3">
            <h4 className="text-sm font-bold text-white uppercase tracking-wider font-heading">
              Commercial Fleet
            </h4>
            <ul className="space-y-2">
              {VEHICLES.map((v) => (
                <li key={v.id}>
                  <a
                    href="#fleet"
                    className="hover:text-orange-400 transition-colors flex items-center gap-1.5"
                  >
                    <span className="text-orange-500">•</span>
                    <span>{v.name}</span>
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Col 4: Contact & Dispatch */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="text-sm font-bold text-white uppercase tracking-wider font-heading">
              Contact Dispatch
            </h4>
            <div className="space-y-2.5">
              <a
                href={`tel:${BUSINESS_INFO.mobile}`}
                className="flex items-center gap-2 text-slate-300 hover:text-orange-400 transition-colors"
              >
                <Phone className="w-4 h-4 text-orange-500 shrink-0" />
                <span className="font-bold text-white text-sm">{BUSINESS_INFO.mobileFormatted}</span>
              </a>

              <a
                href={`https://wa.me/91${BUSINESS_INFO.whatsapp}?text=${encodeURIComponent(
                  'Hello Deliver Express, I need logistics transport in Delhi NCR.'
                )}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-slate-300 hover:text-green-400 transition-colors"
              >
                <MessageSquare className="w-4 h-4 text-green-500 shrink-0" />
                <span>WhatsApp: {BUSINESS_INFO.whatsappFormatted}</span>
              </a>

              <a
                href={`mailto:${BUSINESS_INFO.email}`}
                className="flex items-center gap-2 text-slate-300 hover:text-orange-400 transition-colors break-all"
              >
                <Mail className="w-4 h-4 text-orange-500 shrink-0" />
                <span>{BUSINESS_INFO.email}</span>
              </a>

              <div className="flex items-start gap-2 text-slate-400 pt-1">
                <MapPin className="w-4 h-4 text-orange-500 shrink-0 mt-0.5" />
                <span>{BUSINESS_INFO.operatingRegion}</span>
              </div>
            </div>
          </div>

        </div>

        {/* Bottom copyright & back to top */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-slate-500">
          <div>
            © {new Date().getFullYear()} <span className="text-slate-300 font-semibold">{BUSINESS_INFO.companyName}</span> - {BUSINESS_INFO.title}. All rights reserved. Serving Delhi, Gurugram, Noida, Ghaziabad & Faridabad.
          </div>

          <button
            onClick={scrollToTop}
            className="flex items-center gap-1 text-slate-400 hover:text-amber-400 transition-colors font-semibold"
          >
            <span>Back to Top</span>
            <ArrowUp className="w-3.5 h-3.5" />
          </button>
        </div>

      </div>
    </footer>
  );
}
