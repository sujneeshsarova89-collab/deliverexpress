import { useState, FormEvent } from 'react';
import { Phone, MessageSquare, ShieldCheck, Clock, CheckCircle2, ArrowRight, Zap, Sparkles, Scale } from 'lucide-react';
import { BUSINESS_INFO, VEHICLES, SERVICES } from '../data/logisticsData';
import { createWhatsAppUrl } from '../utils/whatsappHelper';

interface HeroProps {
  onOpenBookingModal: (preselectedVehicle?: string, preselectedService?: string) => void;
}

export default function Hero({ onOpenBookingModal }: HeroProps) {
  const [selectedVehicle, setSelectedVehicle] = useState('tata-ace');
  const [selectedService, setSelectedService] = useState('per_kg');
  const [pickup, setPickup] = useState('');
  const [drop, setDrop] = useState('');

  const currentVehicle = VEHICLES.find((v) => v.id === selectedVehicle) || VEHICLES[1];
  const currentService = SERVICES.find((s) => s.id === selectedService) || SERVICES[0];

  const handleHeroQuickQuote = (e: FormEvent) => {
    e.preventDefault();
    const url = createWhatsAppUrl({
      vehicleName: currentVehicle.name,
      serviceName: currentService.title,
      pickup: pickup || 'Delhi NCR Area',
      drop: drop || 'Destination Hub (e.g. Jaipur / NCR)',
      customMessage: selectedService === 'per_kg'
        ? 'Inquiry for Per Kg Transportation. Special route: Delhi to Jaipur (₹9/kg next day). Min weight: 50kg, max weight: unlimited.'
        : 'Requesting rate quotation & immediate vehicle availability check.',
    });
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <section className="relative overflow-hidden bg-slate-50 border-b border-slate-200 text-slate-900 py-12 lg:py-20">
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-10 items-center">
          
          {/* Left Column: Hero Content & Sleek Interface Aesthetics */}
          <div className="lg:col-span-7 space-y-6 text-left">
            <div className="space-y-4">
              <span className="bg-orange-100 text-orange-700 px-4 py-1.5 rounded-md text-xs font-bold uppercase tracking-wider inline-block">
                Cargo & Logistics Redefined
              </span>

              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-slate-900 leading-[1.1] font-heading tracking-tight">
                Efficiency in <br />
                <span className="text-orange-600">Every Mile.</span>
              </h1>

              <p className="text-base sm:text-lg text-slate-600 max-w-lg leading-relaxed font-sans">
                Providing Both Side Hub to Hub per-kg freight starting at ₹9/kg across 10 dedicated North India corridors (Jaipur, Mohali, Chandigarh, Ambala, Ludhiana, Jalandhar, Rajasthan, Lucknow, Kanpur, Allahabad), dedicated commercial fleets, and fixed monthly contracts.
              </p>
            </div>

            {/* Sleek Feature Cards */}
            <div className="flex flex-col sm:flex-row gap-4 pt-1">
              <div className="flex items-center bg-white p-4 rounded-xl shadow-sm border border-slate-200/80 flex-1 hover:border-orange-200 transition-colors">
                <div className="w-12 h-12 bg-orange-50 rounded-full flex items-center justify-center mr-4 shrink-0 text-xl text-orange-600">
                  <Scale className="w-6 h-6 text-orange-600" />
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 text-sm">Both Side Hub to Hub</h4>
                  <p className="text-xs text-slate-500">10 Corridors from ₹9 / kg (Min 50kg, Max Unlimited)</p>
                </div>
              </div>

              <div className="flex items-center bg-white p-4 rounded-xl shadow-sm border border-slate-200/80 flex-1 hover:border-orange-200 transition-colors">
                <div className="w-12 h-12 bg-slate-100 rounded-full flex items-center justify-center mr-4 shrink-0 text-xl text-slate-700">
                  <ShieldCheck className="w-6 h-6 text-slate-800" />
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 text-sm">Monthly Basis</h4>
                  <p className="text-xs text-slate-500">Fixed commercial vehicle hire</p>
                </div>
              </div>
            </div>

            {/* Call to Action Buttons */}
            <div className="flex flex-wrap items-center gap-3 pt-2">
              <a
                id="hero-call-now-btn"
                href={`tel:${BUSINESS_INFO.mobile}`}
                className="inline-flex items-center justify-center gap-2.5 px-6 py-3.5 rounded-xl bg-orange-600 hover:bg-orange-700 text-white font-extrabold text-sm sm:text-base shadow-lg shadow-orange-200 active:scale-95 transition-all"
              >
                <Phone className="w-5 h-5 fill-current" />
                <span>Call: {BUSINESS_INFO.mobile}</span>
              </a>

              <a
                id="hero-whatsapp-btn"
                href={`https://wa.me/91${BUSINESS_INFO.whatsapp}?text=${encodeURIComponent(
                  'Hello Deliver Express, I need logistics transport in Delhi NCR. Please provide vehicle rates.'
                )}`}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-2 px-5 py-3.5 rounded-xl bg-green-600 hover:bg-green-700 text-white font-bold text-sm sm:text-base shadow-sm active:scale-95 transition-all"
              >
                <MessageSquare className="w-5 h-5 fill-current" />
                <span>Chat on WhatsApp</span>
              </a>

              <button
                id="hero-view-fleet-btn"
                onClick={() => onOpenBookingModal()}
                className="inline-flex items-center justify-center gap-2 px-5 py-3.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-semibold text-sm transition-all"
              >
                <span>Custom Quote</span>
                <ArrowRight className="w-4 h-4 text-orange-400" />
              </button>
            </div>

            {/* Fleet quick pill list */}
            <div className="pt-2 text-xs text-slate-500">
              <span className="font-semibold text-slate-800">Commercial Fleet:</span> Maruti Eeco • Tata Ace • Bolero Pickup • 14 Ft Canter • 17 Ft Canter
            </div>
          </div>

          {/* Right Column: Sleek Interface Flagship Card (Available Fleet & Services + Dispatch Form) */}
          <div className="lg:col-span-5">
            <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-2xl space-y-6">
              <div className="border-b border-slate-100 pb-4 flex items-center justify-between">
                <div>
                  <h3 className="text-xl font-bold text-slate-900 font-heading">
                    Available Fleet & Services
                  </h3>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Fast commercial transport across Delhi NCR
                  </p>
                </div>
                <div className="w-2.5 h-2.5 rounded-full bg-green-500 animate-pulse" title="Ready for dispatch" />
              </div>

              {/* Fleet Categories Preview */}
              <div className="space-y-2.5">
                <div 
                  onClick={() => setSelectedVehicle('tata-ace')}
                  className={`flex justify-between items-center p-3 rounded-xl cursor-pointer transition-colors ${
                    selectedVehicle === 'eeco' || selectedVehicle === 'tata-ace'
                      ? 'bg-orange-50/80 border border-orange-200'
                      : 'bg-slate-50 hover:bg-slate-100 border border-transparent'
                  }`}
                >
                  <span className="font-medium text-slate-800 text-xs sm:text-sm">Eeco & Tata Ace</span>
                  <span className="text-[10px] font-bold text-orange-600 bg-white px-2 py-0.5 rounded border border-orange-200">
                    COMPACT
                  </span>
                </div>

                <div 
                  onClick={() => setSelectedVehicle('bolero')}
                  className={`flex justify-between items-center p-3 rounded-xl cursor-pointer transition-colors ${
                    selectedVehicle === 'bolero'
                      ? 'bg-orange-50/80 border border-orange-200'
                      : 'bg-slate-50 hover:bg-slate-100 border border-transparent'
                  }`}
                >
                  <span className="font-medium text-slate-800 text-xs sm:text-sm">Bolero Pickup</span>
                  <span className="text-[10px] font-bold text-orange-600 bg-white px-2 py-0.5 rounded border border-orange-200">
                    MID-SIZE
                  </span>
                </div>

                <div 
                  onClick={() => setSelectedVehicle('canter-14')}
                  className={`flex justify-between items-center p-3 rounded-xl cursor-pointer transition-colors ${
                    selectedVehicle === 'canter-14' || selectedVehicle === 'canter-17'
                      ? 'bg-orange-50/80 border border-orange-200'
                      : 'bg-slate-50 hover:bg-slate-100 border border-transparent'
                  }`}
                >
                  <span className="font-medium text-slate-800 text-xs sm:text-sm">14 & 17 Feet Canter</span>
                  <span className="text-[10px] font-bold text-orange-600 bg-white px-2 py-0.5 rounded border border-orange-200">
                    HEAVY DUTY
                  </span>
                </div>
              </div>

              {/* Option A & Option B Toggle Pills */}
              <div className="grid grid-cols-2 gap-3 pt-1">
                <button
                  type="button"
                  onClick={() => setSelectedService('per_kg')}
                  className={`p-3.5 rounded-2xl text-center transition-all ${
                    selectedService === 'per_kg'
                      ? 'bg-orange-600 text-white shadow-lg shadow-orange-200'
                      : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  <span className={`block text-[10px] uppercase font-semibold mb-0.5 ${selectedService === 'per_kg' ? 'text-orange-200' : 'text-slate-400'}`}>
                    Per Kg Freight
                  </span>
                  <span className="font-bold text-xs sm:text-sm">From ₹9 / Kg</span>
                </button>

                <button
                  type="button"
                  onClick={() => setSelectedService('full_truck')}
                  className={`p-3.5 rounded-2xl text-center transition-all ${
                    selectedService === 'full_truck'
                      ? 'bg-slate-900 text-white shadow-md'
                      : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  <span className={`block text-[10px] uppercase font-semibold mb-0.5 ${selectedService === 'full_truck' ? 'text-slate-300' : 'text-slate-400'}`}>
                    Full Vehicle
                  </span>
                  <span className="font-bold text-xs sm:text-sm">Full Loading (FTL)</span>
                </button>
              </div>

              {/* Instant WhatsApp Quick Rate Checker */}
              <form onSubmit={handleHeroQuickQuote} className="space-y-3 pt-2 text-left">
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                      Pickup Hub
                    </label>
                    <input
                      id="hero-pickup-input"
                      type="text"
                      placeholder="e.g. Okhla / Gurugram"
                      value={pickup}
                      onChange={(e) => setPickup(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 text-slate-900 rounded-xl px-3 py-2 text-xs focus:outline-none focus:ring-2 focus:ring-orange-500"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                      Drop Hub
                    </label>
                    <input
                      id="hero-drop-input"
                      type="text"
                      placeholder="e.g. Noida / Faridabad"
                      value={drop}
                      onChange={(e) => setDrop(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 text-slate-900 rounded-xl px-3 py-2 text-xs focus:outline-none focus:ring-2 focus:ring-orange-500"
                    />
                  </div>
                </div>

                <div className="bg-slate-50 rounded-xl p-3 border border-slate-200/80 text-xs text-slate-600 flex items-center justify-between">
                  <div>
                    <span className="text-slate-400">Selected:</span>{' '}
                    <span className="font-bold text-slate-900">{currentVehicle.name}</span>
                  </div>
                  <div>
                    <span className="text-slate-400">Payload:</span>{' '}
                    <span className="font-bold text-orange-600">{currentVehicle.payloadCapacity}</span>
                  </div>
                </div>

                <button
                  id="hero-quick-quote-submit"
                  type="submit"
                  className="w-full py-3 px-4 rounded-xl bg-orange-600 hover:bg-orange-700 text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-md shadow-orange-200 transition-all active:scale-98"
                >
                  <MessageSquare className="w-4 h-4 fill-current" />
                  <span>Check Instant Rate on WhatsApp</span>
                </button>
              </form>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
