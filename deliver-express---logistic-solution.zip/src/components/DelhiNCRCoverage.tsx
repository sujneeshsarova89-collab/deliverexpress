import { MapPin, Navigation, Clock, CheckCircle } from 'lucide-react';
import { NCR_HUBS, BUSINESS_INFO } from '../data/logisticsData';

export default function DelhiNCRCoverage() {
  return (
    <section id="coverage" className="py-16 sm:py-20 bg-slate-50 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-10">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <span className="bg-orange-100 text-orange-700 px-4 py-1.5 rounded-md text-xs font-bold uppercase tracking-wider mb-3 inline-block">
            Complete Regional Network
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight font-heading">
            Delhi NCR Coverage & Industrial Corridors
          </h2>
          <p className="mt-3 text-base text-slate-600">
            From the bustling wholesale markets of Old Delhi to the expansive manufacturing belts of IMT Manesar and Greater Noida, our fleet operates continuously across all major industrial estates.
          </p>
        </div>

        {/* Coverage Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {NCR_HUBS.map((hub, idx) => (
            <div
              key={idx}
              className="bg-white rounded-3xl p-6 border border-slate-200 hover:border-orange-200 hover:shadow-xl transition-all duration-200 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 rounded-xl bg-orange-50 text-orange-600 flex items-center justify-center font-bold">
                    <MapPin className="w-5 h-5" />
                  </div>
                  <h3 className="text-lg font-bold text-slate-900 font-heading">
                    {hub.region}
                  </h3>
                </div>

                <div className="space-y-2">
                  <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
                    Key Operating Hubs & Industrial Zones:
                  </span>
                  <ul className="space-y-1.5">
                    {hub.areas.map((area, areaIdx) => (
                      <li key={areaIdx} className="flex items-start gap-2 text-xs text-slate-700">
                        <CheckCircle className="w-3.5 h-3.5 text-green-600 shrink-0 mt-0.5" />
                        <span>{area}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
                <span className="flex items-center gap-1 font-medium text-slate-700">
                  <Clock className="w-3.5 h-3.5 text-orange-600" />
                  Prompt Fleet Dispatch
                </span>
                <span className="text-orange-600 font-bold">Daily Trips</span>
              </div>
            </div>
          ))}

          {/* Quick Dispatch Corridor Card */}
          <div className="bg-slate-900 text-white rounded-3xl p-6 border border-slate-800 flex flex-col justify-between shadow-xl">
            <div>
              <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-orange-500/20 text-orange-400 text-xs font-bold mb-3 border border-orange-500/30">
                North India Linehaul Network
              </div>
              <h3 className="text-lg font-bold text-white font-heading">
                Both Side Hub to Hub: From ₹9 / Kg
              </h3>
              <p className="text-xs text-slate-300 mt-2 leading-relaxed">
                Regular daily linehaul departures connecting Delhi NCR hubs with Jaipur, Mohali, Chandigarh, Ambala, Ludhiana, Jalandhar, Rajasthan, Lucknow, Kanpur, and Allahabad. Same rate in both directions. Min weight 50kg / 100kg, max weight unlimited.
              </p>
            </div>

            <div className="mt-6 pt-4 border-t border-slate-800 flex flex-col gap-2">
              <a
                href="#hub-rates"
                className="w-full py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-orange-400 border border-slate-700 font-bold text-xs flex items-center justify-center gap-2 transition-colors text-center"
              >
                View All 10 Hub to Hub Rates
              </a>
              <a
                href={`tel:${BUSINESS_INFO.mobile}`}
                className="w-full py-2.5 px-4 rounded-xl bg-orange-600 hover:bg-orange-700 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-sm transition-colors"
              >
                Inquire Rates: {BUSINESS_INFO.mobile}
              </a>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
}
