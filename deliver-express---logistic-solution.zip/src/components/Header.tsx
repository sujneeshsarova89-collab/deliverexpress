import { useState } from 'react';
import { Phone, Mail, MessageSquare, Menu, X, MapPin, Truck, ChevronRight } from 'lucide-react';
import { BUSINESS_INFO } from '../data/logisticsData';

interface HeaderProps {
  onOpenBookingModal: (preselectedVehicle?: string, preselectedService?: string) => void;
}

export default function Header({ onOpenBookingModal }: HeaderProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { name: 'Services', href: '#services' },
    { name: 'Hub to Hub Rates', href: '#hub-rates' },
    { name: 'Our Fleet', href: '#fleet' },
    { name: 'Monthly Hire', href: '#monthly-hire' },
    { name: 'Quote Calculator', href: '#quote-calculator' },
    { name: 'Coverage', href: '#coverage' },
    { name: 'Why Us', href: '#why-us' },
    { name: 'Contact', href: '#contact' },
  ];

  const handleNavClick = () => {
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-50 bg-white border-b border-slate-200 shadow-sm">
      {/* Top Notification & Quick Access Bar */}
      <div className="bg-slate-900 text-slate-200 text-xs py-2 px-4 sm:px-10">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="flex items-center gap-2 font-medium">
            <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold bg-orange-600 text-white uppercase tracking-wider">
              Delhi NCR
            </span>
            <span className="flex items-center gap-1 text-slate-300">
              <MapPin className="w-3.5 h-3.5 text-orange-400" />
              Express Dispatch across Delhi, Gurugram, Noida, Ghaziabad & Faridabad
            </span>
          </div>

          <div className="flex items-center gap-4 text-xs font-semibold">
            <a
              id="top-bar-phone-link"
              href={`tel:${BUSINESS_INFO.mobile}`}
              className="flex items-center gap-1.5 text-slate-200 hover:text-orange-400 transition-colors"
              title="Call Deliver Express"
            >
              <Phone className="w-3.5 h-3.5 text-orange-400" />
              <span>{BUSINESS_INFO.mobileFormatted}</span>
            </a>
            <span className="text-slate-600 hidden md:inline">|</span>
            <a
              id="top-bar-email-link"
              href={`mailto:${BUSINESS_INFO.email}`}
              className="hidden md:flex items-center gap-1.5 text-slate-300 hover:text-orange-400 transition-colors"
            >
              <Mail className="w-3.5 h-3.5 text-orange-400" />
              <span>{BUSINESS_INFO.email}</span>
            </a>
          </div>
        </div>
      </div>

      {/* Main Navbar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-10">
        <div className="flex items-center justify-between h-20">
          {/* Logo & Branding - Sleek Interface style with orange square & DE initials */}
          <a href="#" className="flex items-center space-x-3 group">
            <div className="w-10 h-10 bg-orange-600 rounded-lg flex items-center justify-center shadow-sm group-hover:bg-orange-700 transition-colors">
              <span className="text-white font-black text-xl tracking-tight">DE</span>
            </div>
            <div className="flex flex-col">
              <span className="text-2xl font-bold tracking-tighter text-slate-900 leading-none">
                DELIVER <span className="text-orange-600">EXPRESS</span>
              </span>
              <span className="text-[10px] uppercase tracking-widest text-slate-400 font-semibold mt-1">
                Cargo & Logistics Redefined
              </span>
            </div>
          </a>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center space-x-7">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className="text-sm font-medium text-slate-600 hover:text-orange-600 transition-colors"
              >
                {link.name}
              </a>
            ))}
          </nav>

          {/* Action CTAs & Delhi NCR Badge */}
          <div className="hidden sm:flex items-center gap-3">
            <div className="bg-slate-900 text-white px-4 py-1.5 rounded-full text-xs font-semibold tracking-wide hidden xl:inline-block">
              DELHI NCR
            </div>

            <a
              id="nav-whatsapp-cta"
              href={`https://wa.me/91${BUSINESS_INFO.whatsapp}?text=${encodeURIComponent(
                'Hello Deliver Express! I would like to inquire about vehicle availability and rates in Delhi NCR.'
              )}`}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-bold bg-green-600 hover:bg-green-700 text-white shadow-sm transition-all duration-200"
            >
              <MessageSquare className="w-4 h-4 fill-current" />
              <span>WhatsApp</span>
            </a>

            <a
              id="nav-call-cta"
              href={`tel:${BUSINESS_INFO.mobile}`}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold bg-orange-600 hover:bg-orange-700 text-white shadow-md shadow-orange-200 transition-all duration-200"
            >
              <Phone className="w-4 h-4" />
              <span>Call: {BUSINESS_INFO.mobile}</span>
            </a>
          </div>

          {/* Mobile menu button */}
          <div className="flex lg:hidden items-center gap-2">
            <a
              id="mobile-header-call"
              href={`tel:${BUSINESS_INFO.mobile}`}
              className="p-2.5 rounded-lg bg-orange-600 text-white font-bold sm:hidden"
              title="Call Deliver Express"
            >
              <Phone className="w-5 h-5" />
            </a>

            <button
              id="mobile-menu-toggle"
              type="button"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg text-slate-700 hover:text-orange-600 hover:bg-slate-100 transition-colors focus:outline-none"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-slate-200 bg-white px-4 pt-3 pb-6 space-y-3 shadow-xl">
          <div className="grid grid-cols-2 gap-2 pb-3 border-b border-slate-100">
            <a
              href={`tel:${BUSINESS_INFO.mobile}`}
              className="flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-orange-600 text-white font-bold text-xs shadow-sm"
            >
              <Phone className="w-4 h-4" />
              <span>Call Dispatch</span>
            </a>
            <a
              href={`https://wa.me/91${BUSINESS_INFO.whatsapp}?text=${encodeURIComponent(
                'Hello Deliver Express! I want to book a vehicle in Delhi NCR.'
              )}`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-green-600 text-white font-bold text-xs shadow-sm"
            >
              <MessageSquare className="w-4 h-4" />
              <span>WhatsApp</span>
            </a>
          </div>

          <div className="flex flex-col space-y-1">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                onClick={handleNavClick}
                className="flex items-center justify-between px-3 py-2.5 rounded-lg text-sm font-medium text-slate-700 hover:bg-slate-50 hover:text-orange-600 transition-colors"
              >
                <span>{link.name}</span>
                <ChevronRight className="w-4 h-4 text-slate-400" />
              </a>
            ))}
          </div>

          <div className="pt-2">
            <button
              id="mobile-drawer-book-btn"
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenBookingModal();
              }}
              className="w-full py-3 rounded-lg bg-slate-900 text-white font-bold text-sm hover:bg-slate-800 transition-colors shadow"
            >
              Request Custom Quote / Booking
            </button>
          </div>
        </div>
      )}
    </header>
  );
}
