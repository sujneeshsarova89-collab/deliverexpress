import { useState } from 'react';
import { Truck, Check, MessageSquare, Phone, ArrowUpRight, Scale, Maximize2, Shield, Sparkles } from 'lucide-react';
import { VEHICLES, BUSINESS_INFO } from '../data/logisticsData';
import { Vehicle } from '../types';

interface FleetSectionProps {
  onBookVehicle: (vehicleId: string) => void;
}

export default function FleetSection({ onBookVehicle }: FleetSectionProps) {
  const [filter, setFilter] = useState<'ALL' | 'Light Commercial' | 'Medium Commercial' | 'Heavy Canter'>('ALL');

  const filteredVehicles = filter === 'ALL' 
    ? VEHICLES 
    : VEHICLES.filter((v) => v.category === filter);

  return (
    <section id="fleet" className="py-16 sm:py-20 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
          <div className="max-w-2xl">
            <span className="bg-orange-100 text-orange-700 px-4 py-1.5 rounded-md text-xs font-bold uppercase tracking-wider mb-3 inline-block">
              Verified Fleet
            </span>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight font-heading">
              Our Complete Commercial Fleet
            </h2>
            <p className="mt-2 text-base text-slate-600">
              From compact urban vans for tight Delhi streets to 17ft heavy-duty canters for large factory consignments. All vehicles are commercial-registered, fitness-checked, and GPS-enabled.
            </p>
          </div>

          {/* Category Filter Pills */}
          <div className="flex flex-wrap gap-1.5 p-1.5 bg-slate-100 rounded-xl self-start md:self-auto border border-slate-200">
            {(['ALL', 'Light Commercial', 'Medium Commercial', 'Heavy Canter'] as const).map((cat) => (
              <button
                key={cat}
                onClick={() => setFilter(cat)}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                  filter === cat
                    ? 'bg-slate-900 text-white shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {cat === 'ALL' ? 'All Vehicles (5)' : cat}
              </button>
            ))}
          </div>
        </div>

        {/* Fleet Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredVehicles.map((vehicle: Vehicle) => (
            <div
              key={vehicle.id}
              className={`rounded-3xl border transition-all duration-200 flex flex-col justify-between overflow-hidden bg-white ${
                vehicle.popular
                  ? 'border-orange-500 shadow-lg ring-1 ring-orange-400/30'
                  : 'border-slate-200 hover:border-orange-200 hover:shadow-xl'
              }`}
            >
              {/* Header Box */}
              <div className="p-6 pb-4 border-b border-slate-100 bg-gradient-to-b from-slate-50/70 to-white relative">
                {vehicle.popular && (
                  <div className="absolute top-3 right-3 bg-orange-600 text-white font-extrabold text-[10px] px-3 py-0.5 rounded-full flex items-center gap-1 shadow-sm">
                    <Sparkles className="w-3 h-3 fill-current" />
                    <span>Most Popular</span>
                  </div>
                )}

                <div className="inline-block text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-1">
                  {vehicle.category}
                </div>
                <h3 className="text-xl font-bold text-slate-900 font-heading">
                  {vehicle.name}
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  {vehicle.tagline}
                </p>

                {/* Key Spec Badges */}
                <div className="grid grid-cols-2 gap-2 mt-4 pt-3 border-t border-slate-200/60">
                  <div className="bg-orange-50/80 rounded-xl p-2.5 border border-orange-100">
                    <div className="flex items-center gap-1.5 text-[11px] font-semibold text-orange-900">
                      <Scale className="w-3.5 h-3.5 text-orange-600" />
                      <span>Capacity</span>
                    </div>
                    <div className="text-xs font-bold text-slate-900 mt-0.5">
                      {vehicle.payloadCapacity}
                    </div>
                  </div>

                  <div className="bg-slate-100 rounded-xl p-2.5 border border-slate-200/60">
                    <div className="flex items-center gap-1.5 text-[11px] font-semibold text-slate-700">
                      <Maximize2 className="w-3.5 h-3.5 text-slate-500" />
                      <span>Dimensions</span>
                    </div>
                    <div className="text-xs font-bold text-slate-900 mt-0.5 truncate" title={vehicle.dimensions}>
                      {vehicle.dimensions}
                    </div>
                  </div>
                </div>
              </div>

              {/* Body: Features & Best Use Cases */}
              <div className="p-6 pt-4 flex-1 space-y-4">
                <div>
                  <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block mb-2">
                    Ideal Cargo & Use Cases:
                  </span>
                  <ul className="space-y-1.5">
                    {vehicle.bestFor.map((item, idx) => (
                      <li key={idx} className="flex items-start gap-2 text-xs text-slate-700">
                        <Check className="w-3.5 h-3.5 text-green-600 shrink-0 mt-0.5" />
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="pt-2">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
                    Industry Suitability:
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {vehicle.idealIndustries.map((ind, idx) => (
                      <span
                        key={idx}
                        className="px-2 py-0.5 rounded text-[10px] font-medium bg-slate-100 text-slate-700"
                      >
                        {ind}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Indicative Pricing Estimate */}
                <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-100 text-xs">
                  <div className="flex justify-between items-center text-slate-600 mb-1">
                    <span>Trip Rate:</span>
                    <span className="font-bold text-slate-900">{vehicle.basePriceEstimate}</span>
                  </div>
                  <div className="flex justify-between items-center text-slate-600">
                    <span>Fixed Monthly Hire:</span>
                    <span className="font-bold text-orange-600">{vehicle.monthlyEstimate}</span>
                  </div>
                </div>
              </div>

              {/* Card Footer Actions */}
              <div className="p-6 pt-0 flex items-center gap-2">
                <button
                  id={`book-vehicle-${vehicle.id}`}
                  onClick={() => onBookVehicle(vehicle.id)}
                  className="flex-1 py-2.5 px-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-colors shadow-sm"
                >
                  <span>Book {vehicle.name.split(' ')[0]}</span>
                  <ArrowUpRight className="w-3.5 h-3.5 text-orange-400" />
                </button>

                <a
                  href={`https://wa.me/91${BUSINESS_INFO.whatsapp}?text=${encodeURIComponent(
                    `Hello Deliver Express, I need to check immediate availability & rates for ${vehicle.name} in Delhi NCR.`
                  )}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-2.5 rounded-xl bg-green-600 hover:bg-green-700 text-white font-bold text-xs transition-colors"
                  title="WhatsApp Availability"
                >
                  <MessageSquare className="w-4 h-4 fill-current" />
                </a>

                <a
                  href={`tel:${BUSINESS_INFO.mobile}`}
                  className="p-2.5 rounded-xl bg-orange-600 hover:bg-orange-700 text-white font-bold text-xs transition-colors shadow-sm"
                  title="Call for Vehicle"
                >
                  <Phone className="w-4 h-4" />
                </a>
              </div>

            </div>
          ))}
        </div>

        {/* Bottom Fleet Guarantee Banner */}
        <div className="mt-12 bg-slate-900 text-white rounded-3xl p-6 sm:p-8 flex flex-col md:flex-row items-center justify-between gap-6 border border-slate-800">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-orange-500/20 text-orange-400 flex items-center justify-center shrink-0">
              <Shield className="w-6 h-6" />
            </div>
            <div>
              <h4 className="text-lg font-bold text-white font-heading">
                All-Inclusive Fleet Assurance
              </h4>
              <p className="text-xs sm:text-sm text-slate-300 mt-0.5">
                Every vehicle comes equipped with commercial permits for Delhi NCR, experienced drivers, and prompt replacement guarantees for monthly contracts.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3 shrink-0 w-full md:w-auto">
            <a
              href={`tel:${BUSINESS_INFO.mobile}`}
              className="flex-1 md:flex-initial text-center py-3 px-6 rounded-xl bg-orange-600 hover:bg-orange-700 text-white font-bold text-xs sm:text-sm shadow-md transition-colors"
            >
              Call Fleet Manager: {BUSINESS_INFO.mobile}
            </a>
          </div>
        </div>

      </div>
    </section>
  );
}
