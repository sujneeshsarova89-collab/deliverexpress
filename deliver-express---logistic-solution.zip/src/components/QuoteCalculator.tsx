import { useState, useId, FormEvent, useEffect } from 'react';
import { Calculator, MessageSquare, Phone, MapPin, Truck, Check, ArrowRight, ArrowLeftRight, Scale, Info } from 'lucide-react';
import { VEHICLES, SERVICES, BUSINESS_INFO, HUB_TO_HUB_ROUTES } from '../data/logisticsData';
import { createWhatsAppUrl } from '../utils/whatsappHelper';

const NCR_CITIES = [
  'Delhi (Okhla / Mayapuri / Kirti Nagar / Central)',
  'Delhi (Bawana / Narela / North)',
  'Delhi (Patparganj / East)',
  'Gurugram (Udyog Vihar / DLF / Cyber Hub)',
  'Manesar (IMT Manesar / Pace City)',
  'Noida (Sector 62 / 63 / 65 / Phase 2)',
  'Greater Noida (Ecotech / Kasna / Surajpur)',
  'Faridabad (Sector 24 / 25 / NIT)',
  'Ghaziabad (Sahibabad / Mohan Nagar / Loni)',
  'Kundli / Sonipat Industrial Corridor',
  'Other / Custom NCR Location'
];

interface QuoteCalculatorProps {
  initialCorridorId?: string;
}

export default function QuoteCalculator({ initialCorridorId }: QuoteCalculatorProps) {
  const [serviceId, setServiceId] = useState('per_kg');
  const [corridorId, setCorridorId] = useState<string>(initialCorridorId || 'delhi-jaipur');
  const [isReverseDirection, setIsReverseDirection] = useState(false);
  const [pickup, setPickup] = useState(NCR_CITIES[0]);
  const [drop, setDrop] = useState(NCR_CITIES[3]);
  const [vehicleId, setVehicleId] = useState('tata-ace');
  const [cargoType, setCargoType] = useState('Commercial Boxes / Carton Cargo');
  const [weight, setWeight] = useState('Under 1 Ton');
  const [kgWeight, setKgWeight] = useState<number>(100);
  
  const pickupSelectId = useId();
  const dropSelectId = useId();
  const vehicleSelectId = useId();
  const serviceSelectId = useId();
  const cargoTypeInputId = useId();
  const weightSelectId = useId();
  const kgWeightInputId = useId();

  // Keep in sync with initialCorridorId if passed
  useEffect(() => {
    if (initialCorridorId) {
      setCorridorId(initialCorridorId);
      setServiceId('per_kg');
    }
  }, [initialCorridorId]);

  const selectedVehicle = VEHICLES.find((v) => v.id === vehicleId) || VEHICLES[1];
  const selectedService = SERVICES.find((s) => s.id === serviceId) || SERVICES[0];
  const activeCorridor = HUB_TO_HUB_ROUTES.find((r) => r.id === corridorId) || HUB_TO_HUB_ROUTES[0];

  // If user switches corridor, ensure minimum weight is at least corridor's min
  const handleCorridorChange = (newCorridorId: string) => {
    setCorridorId(newCorridorId);
    const corr = HUB_TO_HUB_ROUTES.find((r) => r.id === newCorridorId);
    if (corr && kgWeight < corr.minWeightKg) {
      setKgWeight(corr.minWeightKg);
    }
  };

  const effectiveMinWeight = activeCorridor.minWeightKg;
  const billableKg = Math.max(effectiveMinWeight, Number(kgWeight) || effectiveMinWeight);

  // Dynamic estimate calculation logic
  const calculateEstimatedRate = () => {
    if (serviceId === 'per_kg') {
      const totalCost = billableKg * activeCorridor.ratePerKg;
      return `₹${totalCost.toLocaleString('en-IN')} (₹${activeCorridor.ratePerKg} / Kg)`;
    }

    if (serviceId === 'monthly_contract') {
      return selectedVehicle.monthlyEstimate;
    }

    let base = 699;
    if (vehicleId === 'eeco') base = 549;
    if (vehicleId === 'tata-ace') base = 799;
    if (vehicleId === 'bolero') base = 1199;
    if (vehicleId === 'canter-14') base = 2199;
    if (vehicleId === 'canter-17') base = 2899;

    // Service multiplier
    if (serviceId === 'same_day') base = Math.round(base * 1.15);
    if (serviceId === 'part_truck') base = Math.round(base * 0.7);

    // Cross-border/NCR corridor buffer if different locations
    const isInterCity = pickup !== drop;
    const finalMin = isInterCity ? Math.round(base * 1.1) : base;
    const finalMax = Math.round(finalMin * 1.3);

    return `₹${finalMin.toLocaleString('en-IN')} - ₹${finalMax.toLocaleString('en-IN')}`;
  };

  const getCorridorOriginDestination = () => {
    if (!isReverseDirection) {
      return {
        origin: 'Delhi Hub',
        destination: `${activeCorridor.city} Hub (${activeCorridor.hubLocation})`
      };
    } else {
      return {
        origin: `${activeCorridor.city} Hub (${activeCorridor.hubLocation})`,
        destination: 'Delhi Hub'
      };
    }
  };

  const handleSendWhatsApp = (e: FormEvent) => {
    e.preventDefault();
    const routeInfo = getCorridorOriginDestination();
    
    let customMessage = '';
    if (serviceId === 'per_kg') {
      customMessage = `Both Side Hub to Hub Cargo Inquiry
• Corridor: ${routeInfo.origin} ➔ ${routeInfo.destination}
• Weight: ${kgWeight} kg (Billable: ${billableKg} kg, Min required: ${effectiveMinWeight} kg)
• Rate: ₹${activeCorridor.ratePerKg} / kg
• Calculated Total: ${calculateEstimatedRate()}
• Max Capacity: Unlimited
• Cargo: ${cargoType}
• Service: Both Side Hub to Hub (${activeCorridor.transitTime})`;
    } else {
      customMessage = `Fleet Booking Inquiry
• Service: ${selectedService.title}
• Vehicle: ${selectedVehicle.name}
• Route: ${pickup} ➔ ${drop}
• Cargo: ${cargoType} | Approx Weight: ${weight}
• Indicative Rate: ${calculateEstimatedRate()}`;
    }

    const url = createWhatsAppUrl({
      vehicleName: serviceId === 'per_kg' ? 'Consolidated Hub Fleet' : selectedVehicle.name,
      serviceName: selectedService.title,
      pickup: serviceId === 'per_kg' ? routeInfo.origin : pickup,
      drop: serviceId === 'per_kg' ? routeInfo.destination : drop,
      customMessage: customMessage,
    });
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <section id="quote-calculator" className="py-16 sm:py-20 bg-slate-50 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-10">
        
        {/* Title */}
        <div className="text-center max-w-3xl mx-auto mb-10">
          <span className="bg-orange-100 text-orange-700 px-4 py-1.5 rounded-md text-xs font-bold uppercase tracking-wider mb-3 inline-block">
            Transparent Freight & Cargo Estimator
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight font-heading">
            Freight & Hub-to-Hub Rate Calculator
          </h2>
          <p className="mt-2 text-base text-slate-600">
            Select any of our 10 Both-Side Hub to Hub corridors or intra-NCR vehicle services for instant tariff calculation and one-click WhatsApp dispatch.
          </p>
        </div>

        {/* Quick Corridor Selection Bar */}
        <div className="mb-8 max-w-5xl mx-auto bg-slate-900 rounded-3xl p-5 text-white shadow-xl border border-slate-800">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 mb-3">
            <div className="flex items-center gap-2">
              <span className="w-8 h-8 rounded-lg bg-orange-600 flex items-center justify-center font-bold text-white text-sm">
                ⇄
              </span>
              <div>
                <span className="text-[10px] uppercase font-bold tracking-wider text-orange-400">
                  Quick Select Corridor
                </span>
                <h4 className="text-sm font-bold text-white">
                  10 Both-Side Hub to Hub Corridors
                </h4>
              </div>
            </div>

            <span className="text-[11px] text-slate-400 bg-slate-800 px-2.5 py-1 rounded-full border border-slate-700">
              Same ₹/kg rate in both directions
            </span>
          </div>

          {/* Corridor Pills Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2">
            {HUB_TO_HUB_ROUTES.map((route) => {
              const isSelected = serviceId === 'per_kg' && corridorId === route.id;
              return (
                <button
                  type="button"
                  key={route.id}
                  onClick={() => {
                    setServiceId('per_kg');
                    handleCorridorChange(route.id);
                  }}
                  className={`p-2.5 rounded-xl text-left border transition-all flex flex-col justify-between ${
                    isSelected
                      ? 'bg-orange-600 border-orange-500 text-white shadow-md'
                      : 'bg-slate-800/80 border-slate-700 text-slate-300 hover:bg-slate-800 hover:text-white'
                  }`}
                >
                  <span className="text-xs font-bold truncate">{route.city}</span>
                  <div className="flex items-center justify-between mt-1 text-[11px]">
                    <span className={isSelected ? 'text-white font-extrabold' : 'text-orange-400 font-bold'}>
                      ₹{route.ratePerKg}/kg
                    </span>
                    <span className={`text-[10px] ${isSelected ? 'text-orange-100' : 'text-slate-400'}`}>
                      Min {route.minWeightKg}kg
                    </span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Main Calculator Card */}
        <div className="bg-white rounded-3xl border border-slate-200 shadow-2xl p-6 sm:p-10 max-w-5xl mx-auto">
          <form onSubmit={handleSendWhatsApp} className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            
            {/* Left Column: Form Inputs */}
            <div className="lg:col-span-7 space-y-6">
              
              {/* Service Type Selection */}
              <div>
                <label htmlFor={serviceSelectId} className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">
                  1. Select Service Category
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {SERVICES.map((s) => (
                    <button
                      type="button"
                      key={s.id}
                      onClick={() => setServiceId(s.id)}
                      className={`p-3 text-xs font-bold rounded-xl text-left border transition-all flex flex-col justify-between ${
                        serviceId === s.id
                          ? 'bg-orange-50 border-orange-500 text-slate-950 ring-2 ring-orange-200'
                          : 'bg-white border-slate-200 text-slate-600 hover:border-slate-300'
                      }`}
                    >
                      <span className="truncate">{s.title}</span>
                      <span className="text-[10px] font-medium text-slate-500 mt-1 block">
                        {s.badge}
                      </span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Per-Kg Hub-to-Hub Configuration */}
              {serviceId === 'per_kg' ? (
                <div className="space-y-4">
                  {/* Corridor Selection & Direction Toggle */}
                  <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4">
                    <div className="flex items-center justify-between mb-2">
                      <label className="block text-xs font-bold uppercase tracking-wider text-slate-800">
                        2. Both Side Hub Corridor
                      </label>
                      <span className="text-[11px] font-bold text-orange-700 bg-orange-100 px-2 py-0.5 rounded-full">
                        ₹{activeCorridor.ratePerKg} / Kg
                      </span>
                    </div>

                    <select
                      value={corridorId}
                      onChange={(e) => handleCorridorChange(e.target.value)}
                      className="w-full bg-white border border-slate-300 text-slate-900 rounded-xl px-3.5 py-2.5 text-xs font-bold focus:ring-2 focus:ring-orange-500"
                    >
                      {HUB_TO_HUB_ROUTES.map((route) => (
                        <option key={route.id} value={route.id}>
                          {route.routeDisplay} — ₹{route.ratePerKg}/kg (Min {route.minWeightKg} kg)
                        </option>
                      ))}
                    </select>

                    {/* Direction Switcher (Both Side Hub to Hub) */}
                    <div className="mt-3 p-2.5 bg-white rounded-xl border border-slate-200 flex items-center justify-between gap-2">
                      <div className="text-xs">
                        <span className="text-slate-400 text-[10px] uppercase font-bold block">Current Route:</span>
                        <span className="font-bold text-slate-900">
                          {isReverseDirection
                            ? `${activeCorridor.city} Hub ➔ Delhi Hub`
                            : `Delhi Hub ➔ ${activeCorridor.city} Hub`}
                        </span>
                      </div>

                      <button
                        type="button"
                        onClick={() => setIsReverseDirection(!isReverseDirection)}
                        className="px-3 py-1.5 rounded-lg bg-orange-100 hover:bg-orange-200 text-orange-800 font-bold text-xs flex items-center gap-1.5 transition-colors shrink-0"
                        title="Swap Origin and Destination"
                      >
                        <ArrowLeftRight className="w-3.5 h-3.5" />
                        <span>Switch Direction</span>
                      </button>
                    </div>

                    <p className="text-[11px] text-slate-500 mt-2 flex items-center gap-1">
                      <Info className="w-3.5 h-3.5 text-orange-600 shrink-0" />
                      <span>{activeCorridor.note}</span>
                    </p>
                  </div>

                  {/* Weight Input Box */}
                  <div className="bg-orange-50/70 border border-orange-200 rounded-2xl p-4">
                    <div className="flex items-center justify-between mb-2">
                      <label htmlFor={kgWeightInputId} className="block text-xs font-bold uppercase tracking-wider text-slate-800">
                        3. Cargo Weight (Min {activeCorridor.minWeightKg} Kg, Max Unlimited)
                      </label>
                      <span className="text-[11px] font-bold text-slate-700 bg-white px-2 py-0.5 rounded border border-orange-200">
                        Min Required: {activeCorridor.minWeightKg} Kg
                      </span>
                    </div>

                    <div className="flex items-center gap-3">
                      <input
                        id={kgWeightInputId}
                        type="number"
                        min={1}
                        value={kgWeight}
                        onChange={(e) => setKgWeight(Math.max(0, Number(e.target.value)))}
                        className="w-36 bg-white border border-slate-300 text-slate-900 rounded-xl px-3 py-2 text-sm font-bold focus:ring-2 focus:ring-orange-500"
                      />
                      <span className="text-xs font-semibold text-slate-700">Kilograms (Kg)</span>
                    </div>

                    {kgWeight < activeCorridor.minWeightKg && (
                      <p className="text-[11px] text-amber-800 font-semibold mt-1.5 flex items-center gap-1">
                        ⚠️ Entered weight ({kgWeight} kg) is below corridor minimum ({activeCorridor.minWeightKg} kg). Billable weight will be calculated as {activeCorridor.minWeightKg} kg.
                      </p>
                    )}

                    {/* Presets */}
                    <div className="flex flex-wrap items-center gap-1.5 mt-3">
                      <span className="text-[10px] text-slate-500 font-semibold mr-1">Quick Presets:</span>
                      {(activeCorridor.minWeightKg === 100
                        ? [100, 150, 250, 500, 1000, 2500]
                        : [50, 100, 250, 500, 1000, 2500]
                      ).map((wt) => (
                        <button
                          type="button"
                          key={wt}
                          onClick={() => setKgWeight(wt)}
                          className={`text-xs px-2.5 py-1 rounded-lg border font-semibold transition-colors ${
                            kgWeight === wt
                              ? 'bg-orange-600 text-white border-orange-600'
                              : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                          }`}
                        >
                          {wt >= 1000 ? `${wt / 1000} Ton` : `${wt} kg`}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              ) : (
                /* Intra-NCR Vehicle & Location Inputs */
                <div className="space-y-4">
                  <div>
                    <label htmlFor={vehicleSelectId} className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">
                      2. Choose Dedicated Vehicle
                    </label>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                      {VEHICLES.map((v) => (
                        <button
                          type="button"
                          key={v.id}
                          onClick={() => setVehicleId(v.id)}
                          className={`p-3 text-xs font-bold rounded-xl text-left border transition-all ${
                            vehicleId === v.id
                              ? 'bg-slate-900 border-slate-900 text-white shadow-md'
                              : 'bg-white border-slate-200 text-slate-700 hover:border-slate-300'
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <span>{v.name}</span>
                            {vehicleId === v.id && <Check className="w-3.5 h-3.5 text-orange-400" />}
                          </div>
                          <div className={`text-[10px] mt-1 font-normal ${vehicleId === v.id ? 'text-slate-300' : 'text-slate-500'}`}>
                            Cap: {v.payloadCapacity}
                          </div>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Locations Grid */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label htmlFor={pickupSelectId} className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5 flex items-center gap-1">
                        <MapPin className="w-3.5 h-3.5 text-orange-600" />
                        Pickup Location
                      </label>
                      <select
                        id={pickupSelectId}
                        value={pickup}
                        onChange={(e) => setPickup(e.target.value)}
                        className="w-full bg-slate-50 border border-slate-200 text-slate-900 rounded-xl px-3.5 py-2.5 text-xs font-medium focus:ring-2 focus:ring-orange-500 focus:bg-white"
                      >
                        {NCR_CITIES.map((city, idx) => (
                          <option key={idx} value={city}>{city}</option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label htmlFor={dropSelectId} className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5 flex items-center gap-1">
                        <MapPin className="w-3.5 h-3.5 text-orange-600" />
                        Drop Location
                      </label>
                      <select
                        id={dropSelectId}
                        value={drop}
                        onChange={(e) => setDrop(e.target.value)}
                        className="w-full bg-slate-50 border border-slate-200 text-slate-900 rounded-xl px-3.5 py-2.5 text-xs font-medium focus:ring-2 focus:ring-orange-500 focus:bg-white"
                      >
                        {NCR_CITIES.map((city, idx) => (
                          <option key={idx} value={city}>{city}</option>
                        ))}
                      </select>
                    </div>
                  </div>

                  {/* Approx Weight */}
                  <div>
                    <label htmlFor={weightSelectId} className="block text-xs font-medium text-slate-600 mb-1">
                      Approximate Load Weight
                    </label>
                    <select
                      id={weightSelectId}
                      value={weight}
                      onChange={(e) => setWeight(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 text-slate-900 rounded-xl px-3 py-2 text-xs focus:ring-2 focus:ring-orange-500 focus:bg-white"
                    >
                      <option value="Under 500 Kg">Under 500 Kg (Eeco)</option>
                      <option value="Under 1 Ton">500 Kg - 1 Ton (Tata Ace)</option>
                      <option value="1 Ton - 1.7 Ton">1 Ton - 1.7 Ton (Bolero)</option>
                      <option value="2 Ton - 4 Ton">2 Ton - 4 Ton (14 Ft Canter)</option>
                      <option value="4 Ton - 6 Ton">4 Ton - 6 Ton (17 Ft Canter)</option>
                    </select>
                  </div>
                </div>
              )}

              {/* Cargo Description */}
              <div>
                <label htmlFor={cargoTypeInputId} className="block text-xs font-medium text-slate-600 mb-1">
                  Cargo Description / Packaging Type
                </label>
                <input
                  id={cargoTypeInputId}
                  type="text"
                  value={cargoType}
                  onChange={(e) => setCargoType(e.target.value)}
                  placeholder="e.g. Master cartons, textile bales, auto spares, hardware"
                  className="w-full bg-slate-50 border border-slate-200 text-slate-900 rounded-xl px-3 py-2 text-xs focus:ring-2 focus:ring-orange-500 focus:bg-white"
                />
              </div>

            </div>

            {/* Right Column: Calculated Summary Card */}
            <div className="lg:col-span-5 bg-slate-900 text-white rounded-3xl p-6 sm:p-7 flex flex-col justify-between border border-slate-800 shadow-xl">
              <div>
                <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-5">
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-orange-400">
                      Summary Calculation
                    </span>
                    <h3 className="text-lg font-bold text-white font-heading">
                      {serviceId === 'per_kg' ? `${activeCorridor.city} Cargo Freight` : selectedVehicle.name}
                    </h3>
                  </div>
                  <span className="px-2.5 py-1 rounded bg-orange-500/20 text-orange-400 text-xs font-bold border border-orange-500/30">
                    {serviceId === 'per_kg' ? `₹${activeCorridor.ratePerKg} / Kg` : selectedService.badge}
                  </span>
                </div>

                <div className="space-y-3 text-xs">
                  <div className="flex justify-between text-slate-300">
                    <span className="text-slate-400">Service Type:</span>
                    <span className="font-semibold text-white">{selectedService.title}</span>
                  </div>

                  {serviceId === 'per_kg' ? (
                    <>
                      <div className="flex justify-between text-slate-300">
                        <span className="text-slate-400">Corridor Route:</span>
                        <span className="font-bold text-orange-300">
                          {isReverseDirection
                            ? `${activeCorridor.city} ➔ Delhi`
                            : `Delhi ➔ ${activeCorridor.city}`}
                        </span>
                      </div>

                      <div className="flex justify-between text-slate-300">
                        <span className="text-slate-400">Directionality:</span>
                        <span className="font-semibold text-emerald-400 flex items-center gap-1">
                          <ArrowLeftRight className="w-3 h-3" />
                          Both Side Hub to Hub
                        </span>
                      </div>

                      <div className="flex justify-between text-slate-300">
                        <span className="text-slate-400">Entered Weight:</span>
                        <span className="font-medium text-white">{kgWeight} Kg</span>
                      </div>

                      <div className="flex justify-between text-slate-300">
                        <span className="text-slate-400">Billable Weight:</span>
                        <span className="font-bold text-orange-400">{billableKg} Kg</span>
                      </div>

                      <div className="flex justify-between text-slate-300">
                        <span className="text-slate-400">Min Weight Required:</span>
                        <span className="font-semibold text-slate-200">{activeCorridor.minWeightKg} Kg</span>
                      </div>

                      <div className="flex justify-between text-slate-300">
                        <span className="text-slate-400">Max Weight Capacity:</span>
                        <span className="font-semibold text-emerald-400">Unlimited</span>
                      </div>

                      <div className="flex justify-between text-slate-300 bg-slate-800/60 p-2 rounded-lg border border-slate-700/60">
                        <span className="text-slate-400">Estimated Transit:</span>
                        <span className="font-semibold text-white">{activeCorridor.transitTime}</span>
                      </div>
                    </>
                  ) : (
                    <>
                      <div className="flex justify-between text-slate-300">
                        <span className="text-slate-400">Payload Capacity:</span>
                        <span className="font-semibold text-white">{selectedVehicle.payloadCapacity}</span>
                      </div>
                      <div className="flex justify-between text-slate-300">
                        <span className="text-slate-400">Dimensions:</span>
                        <span className="font-semibold text-white">{selectedVehicle.dimensions}</span>
                      </div>
                      <div className="flex justify-between text-slate-300">
                        <span className="text-slate-400">Route Corridor:</span>
                        <span className="font-semibold text-orange-300 truncate max-w-[200px]" title={`${pickup} to ${drop}`}>
                          {pickup.split(' ')[0]} → {drop.split(' ')[0]}
                        </span>
                      </div>
                    </>
                  )}
                </div>

                {/* Rate Display */}
                <div className="mt-6 p-4 rounded-2xl bg-slate-800/80 border border-slate-700">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                    Calculated Tariff ({billableKg} kg × ₹{activeCorridor.ratePerKg}):
                  </span>
                  <div className="text-2xl sm:text-3xl font-black text-orange-400 mt-1 font-heading">
                    {calculateEstimatedRate()}
                  </div>
                  <span className="text-[10px] text-slate-400 block mt-1">
                    {serviceId === 'per_kg'
                      ? `*Both side hub-to-hub rate for ${activeCorridor.city} corridor. Min weight requirement ${activeCorridor.minWeightKg} kg, max unlimited.`
                      : '*Indicative vehicle rental rate. Exact pricing confirmed by dispatch team.'}
                  </span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="mt-6 space-y-2.5">
                <button
                  id="calc-send-whatsapp-btn"
                  type="submit"
                  className="w-full py-3.5 px-4 rounded-xl bg-green-600 hover:bg-green-700 text-white font-bold text-sm flex items-center justify-center gap-2 shadow-sm transition-all active:scale-98"
                >
                  <MessageSquare className="w-4 h-4 fill-current" />
                  <span>Send Request to WhatsApp</span>
                </button>

                <a
                  id="calc-call-dispatcher-btn"
                  href={`tel:${BUSINESS_INFO.mobile}`}
                  className="w-full py-3 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-white border border-slate-700 font-bold text-xs flex items-center justify-center gap-2 transition-all"
                >
                  <Phone className="w-4 h-4 text-orange-400" />
                  <span>Call Dispatcher: {BUSINESS_INFO.mobile}</span>
                </a>
              </div>

            </div>

          </form>
        </div>

      </div>
    </section>
  );
}
