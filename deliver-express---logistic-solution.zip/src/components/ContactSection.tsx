import { useState, useId, FormEvent } from 'react';
import { Phone, MessageSquare, Mail, MapPin, Clock, Send, CheckCircle2 } from 'lucide-react';
import { BUSINESS_INFO, VEHICLES, SERVICES } from '../data/logisticsData';
import { createWhatsAppUrl } from '../utils/whatsappHelper';

export default function ContactSection() {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [vehicle, setVehicle] = useState('tata-ace');
  const [service, setService] = useState('per_kg');
  const [pickup, setPickup] = useState('');
  const [drop, setDrop] = useState('');
  const [message, setMessage] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const nameInputId = useId();
  const phoneInputId = useId();
  const vehicleSelectId = useId();
  const serviceSelectId = useId();
  const pickupInputId = useId();
  const dropInputId = useId();
  const messageInputId = useId();

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    const chosenVehicle = VEHICLES.find((v) => v.id === vehicle)?.name || vehicle;
    const chosenService = SERVICES.find((s) => s.id === service)?.title || service;
    const isPerKg = service === 'per_kg';

    const url = createWhatsAppUrl({
      vehicleName: isPerKg ? 'Consolidated Freight Fleet' : chosenVehicle,
      serviceName: chosenService,
      pickup: pickup || 'Delhi NCR',
      drop: drop || 'Destination Hub (e.g. Jaipur / NCR)',
      customMessage: `From: ${name || 'Customer'} (Contact: ${phone || 'Not provided'})\n${
        isPerKg ? 'Service: Per Kg Transportation (Min 50kg, Max unlimited, Delhi to Jaipur ₹9/kg)\n' : ''
      }Notes: ${message || 'Please provide rates and availability'}`,
    });

    setSubmitted(true);
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <section id="contact" className="py-16 sm:py-20 bg-slate-50 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-10">
        
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <span className="bg-orange-100 text-orange-700 px-4 py-1.5 rounded-md text-xs font-bold uppercase tracking-wider mb-3 inline-block">
            Get in Touch
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight font-heading">
            Connect With Deliver Express Dispatch Team
          </h2>
          <p className="mt-3 text-base text-slate-600">
            Have a question about vehicle availability, route pricing, or fixed monthly contracts? Reach our 24/7 helpline instantly.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Left Column: Direct Contact Details Cards */}
          <div className="lg:col-span-5 space-y-4">
            
            {/* Phone Card */}
            <a
              id="contact-card-phone"
              href={`tel:${BUSINESS_INFO.mobile}`}
              className="flex items-start gap-4 p-5 rounded-3xl bg-white border border-slate-200 hover:border-orange-200 hover:shadow-xl transition-all group"
            >
              <div className="w-12 h-12 rounded-xl bg-orange-50 text-orange-600 flex items-center justify-center shrink-0 shadow-sm group-hover:scale-105 transition-transform">
                <Phone className="w-6 h-6" />
              </div>
              <div>
                <span className="text-[11px] font-bold text-orange-700 uppercase tracking-wider block">
                  Direct Phone Call
                </span>
                <span className="text-lg font-extrabold text-slate-900 block mt-0.5 font-heading">
                  {BUSINESS_INFO.mobileFormatted}
                </span>
                <p className="text-xs text-slate-600 mt-1">
                  24/7 on-call dispatcher for immediate vehicle booking across Delhi NCR.
                </p>
              </div>
            </a>

            {/* WhatsApp Card */}
            <a
              id="contact-card-whatsapp"
              href={`https://wa.me/91${BUSINESS_INFO.whatsapp}?text=${encodeURIComponent(
                'Hello Deliver Express, I need logistics transport in Delhi NCR. Please share vehicle availability.'
              )}`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-start gap-4 p-5 rounded-3xl bg-white border border-slate-200 hover:border-green-200 hover:shadow-xl transition-all group"
            >
              <div className="w-12 h-12 rounded-xl bg-green-50 text-green-600 flex items-center justify-center shrink-0 shadow-sm group-hover:scale-105 transition-transform">
                <MessageSquare className="w-6 h-6 fill-current" />
              </div>
              <div>
                <span className="text-[11px] font-bold text-green-700 uppercase tracking-wider block">
                  WhatsApp Support
                </span>
                <span className="text-lg font-extrabold text-slate-900 block mt-0.5 font-heading">
                  {BUSINESS_INFO.whatsappFormatted}
                </span>
                <p className="text-xs text-slate-600 mt-1">
                  Quick quotation, share pickup/drop location pins, and instant confirmations.
                </p>
              </div>
            </a>

            {/* Email Card */}
            <a
              id="contact-card-email"
              href={`mailto:${BUSINESS_INFO.email}`}
              className="flex items-start gap-4 p-5 rounded-3xl bg-white border border-slate-200 hover:border-slate-300 hover:shadow-xl transition-all group"
            >
              <div className="w-12 h-12 rounded-xl bg-slate-100 text-slate-900 flex items-center justify-center shrink-0 shadow-sm group-hover:scale-105 transition-transform">
                <Mail className="w-6 h-6" />
              </div>
              <div className="overflow-hidden">
                <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
                  Email Inquiries & RFPs
                </span>
                <span className="text-base font-bold text-slate-900 block mt-0.5 truncate font-heading">
                  {BUSINESS_INFO.email}
                </span>
                <p className="text-xs text-slate-600 mt-1">
                  Send corporate logistics tenders, monthly rental agreements & queries.
                </p>
              </div>
            </a>

            {/* Operating Area Card */}
            <div className="p-6 rounded-3xl bg-slate-900 text-white border border-slate-800 shadow-xl">
              <div className="flex items-center gap-2 text-orange-400 text-xs font-bold uppercase tracking-wider mb-2">
                <MapPin className="w-4 h-4" />
                Service Coverage Region
              </div>
              <p className="text-sm font-semibold text-white">
                Delhi NCR & Adjoining Industrial Belts
              </p>
              <p className="text-xs text-slate-400 mt-1">
                New Delhi, Gurugram, Manesar, Noida, Greater Noida, Ghaziabad, Faridabad & Kundli.
              </p>
              <div className="mt-3 flex items-center gap-2 text-xs text-slate-300">
                <Clock className="w-4 h-4 text-orange-400" />
                <span>Operating 24 Hours, 7 Days a Week</span>
              </div>
            </div>

          </div>

          {/* Right Column: Interactive Booking & Inquiry Form */}
          <div className="lg:col-span-7 bg-white rounded-3xl border border-slate-200 p-6 sm:p-10 shadow-2xl">
            <h3 className="text-xl font-bold text-slate-900 font-heading mb-1">
              Send an Online Booking Request
            </h3>
            <p className="text-xs text-slate-600 mb-6">
              Fill in your details below and our dispatcher will get back to you immediately with rates and availability.
            </p>

            {submitted ? (
              <div className="bg-green-50 border border-green-200 rounded-2xl p-6 text-center space-y-3">
                <CheckCircle2 className="w-12 h-12 text-green-600 mx-auto" />
                <h4 className="text-lg font-bold text-green-950 font-heading">
                  Request Initiated!
                </h4>
                <p className="text-xs text-green-800 max-w-md mx-auto">
                  Your details have been pre-formatted for our dispatch team. If WhatsApp did not open automatically, you can call us directly at <span className="font-bold">{BUSINESS_INFO.mobile}</span>.
                </p>
                <button
                  onClick={() => setSubmitted(false)}
                  className="py-2 px-4 rounded-xl bg-green-600 text-white text-xs font-bold hover:bg-green-700 transition-colors mt-2"
                >
                  Submit Another Request
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4 text-left">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label htmlFor={nameInputId} className="block text-xs font-semibold text-slate-700 mb-1">
                      Your Name / Business Name
                    </label>
                    <input
                      id={nameInputId}
                      type="text"
                      required
                      placeholder="e.g. Rahul Sharma / ABC Traders"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 focus:ring-2 focus:ring-orange-500 focus:bg-white focus:outline-none"
                    />
                  </div>

                  <div>
                    <label htmlFor={phoneInputId} className="block text-xs font-semibold text-slate-700 mb-1">
                      Phone Number (WhatsApp)
                    </label>
                    <input
                      id={phoneInputId}
                      type="tel"
                      required
                      placeholder="e.g. 9876543210"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 focus:ring-2 focus:ring-orange-500 focus:bg-white focus:outline-none"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label htmlFor={vehicleSelectId} className="block text-xs font-semibold text-slate-700 mb-1">
                      Vehicle Preferred
                    </label>
                    <select
                      id={vehicleSelectId}
                      value={vehicle}
                      onChange={(e) => setVehicle(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 focus:ring-2 focus:ring-orange-500 focus:bg-white focus:outline-none"
                    >
                      {VEHICLES.map((v) => (
                        <option key={v.id} value={v.id}>
                          {v.name} ({v.payloadCapacity})
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label htmlFor={serviceSelectId} className="block text-xs font-semibold text-slate-700 mb-1">
                      Service Required
                    </label>
                    <select
                      id={serviceSelectId}
                      value={service}
                      onChange={(e) => setService(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 focus:ring-2 focus:ring-orange-500 focus:bg-white focus:outline-none"
                    >
                      {SERVICES.map((s) => (
                        <option key={s.id} value={s.id}>
                          {s.title}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label htmlFor={pickupInputId} className="block text-xs font-semibold text-slate-700 mb-1">
                      Pickup Address / Area
                    </label>
                    <input
                      id={pickupInputId}
                      type="text"
                      placeholder="e.g. Okhla Phase 2, Delhi"
                      value={pickup}
                      onChange={(e) => setPickup(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 focus:ring-2 focus:ring-orange-500 focus:bg-white focus:outline-none"
                    />
                  </div>

                  <div>
                    <label htmlFor={dropInputId} className="block text-xs font-semibold text-slate-700 mb-1">
                      Drop Address / Area
                    </label>
                    <input
                      id={dropInputId}
                      type="text"
                      placeholder="e.g. Udyog Vihar, Gurugram"
                      value={drop}
                      onChange={(e) => setDrop(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 focus:ring-2 focus:ring-orange-500 focus:bg-white focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label htmlFor={messageInputId} className="block text-xs font-semibold text-slate-700 mb-1">
                    Cargo Details / Extra Instructions
                  </label>
                  <textarea
                    id={messageInputId}
                    rows={3}
                    placeholder="Provide cargo details, approximate weight, timing requirements, or monthly contract questions..."
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs text-slate-900 focus:ring-2 focus:ring-orange-500 focus:bg-white focus:outline-none"
                  ></textarea>
                </div>

                <div className="pt-2 flex flex-col sm:flex-row items-center gap-3">
                  <button
                    id="contact-form-submit-btn"
                    type="submit"
                    className="w-full sm:w-auto flex-1 py-3 px-6 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-sm transition-all"
                  >
                    <Send className="w-4 h-4 text-orange-400" />
                    <span>Submit & Open WhatsApp Dispatch</span>
                  </button>

                  <a
                    id="contact-form-direct-call-btn"
                    href={`tel:${BUSINESS_INFO.mobile}`}
                    className="w-full sm:w-auto py-3 px-5 rounded-xl bg-orange-600 hover:bg-orange-700 text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-md shadow-orange-950 transition-all"
                  >
                    <Phone className="w-4 h-4" />
                    <span>Call: {BUSINESS_INFO.mobile}</span>
                  </a>
                </div>
              </form>
            )}

          </div>

        </div>

      </div>
    </section>
  );
}
