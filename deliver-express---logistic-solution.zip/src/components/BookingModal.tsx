import { useState, useEffect, useId, FormEvent } from 'react';
import { X, MessageSquare, Phone, Truck, Check } from 'lucide-react';
import { BUSINESS_INFO, VEHICLES, SERVICES } from '../data/logisticsData';
import { createWhatsAppUrl } from '../utils/whatsappHelper';

interface BookingModalProps {
  isOpen: boolean;
  onClose: () => void;
  preselectedVehicle?: string;
  preselectedService?: string;
}

export default function BookingModal({
  isOpen,
  onClose,
  preselectedVehicle,
  preselectedService,
}: BookingModalProps) {
  const [vehicle, setVehicle] = useState(preselectedVehicle || 'tata-ace');
  const [service, setService] = useState(preselectedService || 'same_day');
  const [pickup, setPickup] = useState('');
  const [drop, setDrop] = useState('');
  const [cargo, setCargo] = useState('');
  const [customerName, setCustomerName] = useState('');
  const [contactNumber, setContactNumber] = useState('');

  const modalNameInputId = useId();
  const modalPhoneInputId = useId();
  const modalVehicleSelectId = useId();
  const modalServiceSelectId = useId();
  const modalPickupInputId = useId();
  const modalDropInputId = useId();
  const modalCargoInputId = useId();

  useEffect(() => {
    if (preselectedVehicle) setVehicle(preselectedVehicle);
    if (preselectedService) setService(preselectedService);
  }, [preselectedVehicle, preselectedService]);

  if (!isOpen) return null;

  const currentVehicle = VEHICLES.find((v) => v.id === vehicle) || VEHICLES[1];
  const currentService = SERVICES.find((s) => s.id === service) || SERVICES[0];

  const handleModalSubmit = (e: FormEvent) => {
    e.preventDefault();
    const isPerKg = service === 'per_kg';
    const url = createWhatsAppUrl({
      vehicleName: isPerKg ? 'Consolidated Freight Fleet' : currentVehicle.name,
      serviceName: currentService.title,
      pickup: pickup || 'Delhi NCR',
      drop: drop || 'Destination Hub (e.g. Jaipur / NCR)',
      customMessage: `Name: ${customerName || 'Client'} (Ph: ${contactNumber || 'Provided in chat'})\nCargo details: ${cargo || 'General logistics'}${
        isPerKg ? '\nNote: Both Side Hub to Hub Per Kg Cargo inquiry (Corridors starting at ₹9/kg, min 50kg/100kg, max unlimited).' : ''
      }`,
    });
    window.open(url, '_blank', 'noopener,noreferrer');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-fadeIn">
      <div 
        className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border border-slate-200 relative max-h-[90vh] overflow-y-auto"
        role="dialog"
        aria-modal="true"
        aria-labelledby="modal-booking-title"
      >
        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 text-slate-400 hover:text-slate-700 rounded-full hover:bg-slate-100 transition-colors"
          aria-label="Close booking modal"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3 mb-5">
          <div className="w-10 h-10 rounded-xl bg-orange-50 text-orange-600 flex items-center justify-center font-bold">
            <Truck className="w-5 h-5" />
          </div>
          <div>
            <h3 id="modal-booking-title" className="text-xl font-bold text-slate-900 font-heading">
              Quick Vehicle & Freight Booking
            </h3>
            <p className="text-xs text-slate-500">
              Deliver Express • Cargo & Logistics Redefined
            </p>
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleModalSubmit} className="space-y-4 text-left">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label htmlFor={modalNameInputId} className="block text-xs font-semibold text-slate-700 mb-1">
                Your Name
              </label>
              <input
                id={modalNameInputId}
                type="text"
                required
                placeholder="e.g. Amit Kumar"
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:ring-2 focus:ring-orange-500 focus:bg-white"
              />
            </div>
            <div>
              <label htmlFor={modalPhoneInputId} className="block text-xs font-semibold text-slate-700 mb-1">
                Contact Number
              </label>
              <input
                id={modalPhoneInputId}
                type="tel"
                required
                placeholder="e.g. 9810XXXXXX"
                value={contactNumber}
                onChange={(e) => setContactNumber(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:ring-2 focus:ring-orange-500 focus:bg-white"
              />
            </div>
          </div>

          <div>
            <label htmlFor={modalVehicleSelectId} className="block text-xs font-semibold text-slate-700 mb-1">
              Select Vehicle
            </label>
            <select
              id={modalVehicleSelectId}
              value={vehicle}
              onChange={(e) => setVehicle(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 text-xs text-slate-900 font-medium focus:ring-2 focus:ring-orange-500 focus:bg-white"
            >
              {VEHICLES.map((v) => (
                <option key={v.id} value={v.id}>
                  {v.name} ({v.payloadCapacity})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label htmlFor={modalServiceSelectId} className="block text-xs font-semibold text-slate-700 mb-1">
              Required Service
            </label>
            <select
              id={modalServiceSelectId}
              value={service}
              onChange={(e) => setService(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 text-xs text-slate-900 font-medium focus:ring-2 focus:ring-orange-500 focus:bg-white"
            >
              {SERVICES.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.title}
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label htmlFor={modalPickupInputId} className="block text-xs font-semibold text-slate-700 mb-1">
                Pickup Location
              </label>
              <input
                id={modalPickupInputId}
                type="text"
                placeholder="Area in Delhi NCR"
                value={pickup}
                onChange={(e) => setPickup(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:ring-2 focus:ring-orange-500 focus:bg-white"
              />
            </div>
            <div>
              <label htmlFor={modalDropInputId} className="block text-xs font-semibold text-slate-700 mb-1">
                Drop Location
              </label>
              <input
                id={modalDropInputId}
                type="text"
                placeholder="Destination Hub"
                value={drop}
                onChange={(e) => setDrop(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:ring-2 focus:ring-orange-500 focus:bg-white"
              />
            </div>
          </div>

          <div>
            <label htmlFor={modalCargoInputId} className="block text-xs font-semibold text-slate-700 mb-1">
              Cargo Description / Notes
            </label>
            <input
              id={modalCargoInputId}
              type="text"
              placeholder="e.g. 50 Cartons FMCG, 1.2 Ton machinery parts..."
              value={cargo}
              onChange={(e) => setCargo(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:ring-2 focus:ring-orange-500 focus:bg-white"
            />
          </div>

          <div className="bg-orange-50 p-3 rounded-xl border border-orange-200/80 text-xs text-orange-950 flex items-start gap-2">
            <Check className="w-4 h-4 text-orange-600 shrink-0 mt-0.5" />
            <span>
              Direct confirmation via WhatsApp with verified driver contact & vehicle registration.
            </span>
          </div>

          <div className="space-y-2 pt-2">
            <button
              id="modal-submit-whatsapp-btn"
              type="submit"
              className="w-full py-3 px-4 rounded-xl bg-green-600 hover:bg-green-700 text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-sm transition-all active:scale-98"
            >
              <MessageSquare className="w-4 h-4 fill-current" />
              <span>Send Booking Request on WhatsApp</span>
            </button>

            <a
              id="modal-call-btn"
              href={`tel:${BUSINESS_INFO.mobile}`}
              className="w-full py-2.5 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs flex items-center justify-center gap-2 transition-all"
            >
              <Phone className="w-3.5 h-3.5 text-orange-400" />
              <span>Call Dispatch Directly: {BUSINESS_INFO.mobile}</span>
            </a>
          </div>
        </form>
      </div>
    </div>
  );
}
