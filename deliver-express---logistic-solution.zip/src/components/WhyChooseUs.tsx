import { Clock, Calendar, CheckCircle2, BadgePercent, UserCheck, PhoneCall, ShieldCheck } from 'lucide-react';
import { WHY_CHOOSE_US, BUSINESS_INFO } from '../data/logisticsData';

export default function WhyChooseUs() {
  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'Clock':
        return <Clock className="w-6 h-6 text-orange-600" />;
      case 'Calendar':
        return <Calendar className="w-6 h-6 text-orange-600" />;
      case 'CheckCircle2':
        return <CheckCircle2 className="w-6 h-6 text-orange-600" />;
      case 'BadgePercent':
        return <BadgePercent className="w-6 h-6 text-slate-900" />;
      case 'UserCheck':
        return <UserCheck className="w-6 h-6 text-slate-800" />;
      case 'PhoneCall':
        return <PhoneCall className="w-6 h-6 text-orange-600" />;
      default:
        return <ShieldCheck className="w-6 h-6 text-orange-600" />;
    }
  };

  return (
    <section id="why-us" className="py-16 sm:py-20 bg-slate-50 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-10">
        
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <span className="bg-orange-100 text-orange-700 px-4 py-1.5 rounded-md text-xs font-bold uppercase tracking-wider mb-3 inline-block">
            Why Businesses Choose Us
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight font-heading">
            Your Reliable Logistics Partner in Delhi NCR
          </h2>
          <p className="mt-3 text-base text-slate-600">
            We understand that timely transport is critical to your supply chain, factory operations, and customer satisfaction. Here is what sets Deliver Express apart.
          </p>
        </div>

        {/* Feature Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {WHY_CHOOSE_US.map((item, index) => (
            <div
              key={index}
              className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200 shadow-sm hover:shadow-xl hover:border-orange-200 transition-all duration-200 flex flex-col justify-between"
            >
              <div>
                <div className="w-12 h-12 rounded-xl bg-orange-50 flex items-center justify-center mb-4">
                  {getIcon(item.icon)}
                </div>
                <h3 className="text-lg font-bold text-slate-900 mb-2 font-heading">
                  {item.title}
                </h3>
                <p className="text-sm text-slate-600 leading-relaxed">
                  {item.description}
                </p>
              </div>

              <div className="mt-5 pt-3 border-t border-slate-100 text-[11px] font-bold text-orange-600 flex items-center gap-1">
                <span>Guaranteed Standard</span>
              </div>
            </div>
          ))}
        </div>

        {/* Quick CTA strip */}
        <div className="mt-12 text-center">
          <div className="inline-flex flex-wrap items-center justify-center gap-4 bg-white p-5 sm:p-6 rounded-3xl border border-slate-200 shadow-sm">
            <span className="text-sm font-bold text-slate-900">
              Need immediate assistance or vehicle quotation?
            </span>
            <div className="flex items-center gap-2.5">
              <a
                href={`tel:${BUSINESS_INFO.mobile}`}
                className="py-2.5 px-4 rounded-xl bg-orange-600 hover:bg-orange-700 text-white font-bold text-xs flex items-center gap-1.5 shadow-sm transition-colors"
              >
                <PhoneCall className="w-3.5 h-3.5" />
                <span>Call {BUSINESS_INFO.mobile}</span>
              </a>
              <a
                href={`mailto:${BUSINESS_INFO.email}`}
                className="py-2.5 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs transition-colors"
              >
                {BUSINESS_INFO.email}
              </a>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
}
