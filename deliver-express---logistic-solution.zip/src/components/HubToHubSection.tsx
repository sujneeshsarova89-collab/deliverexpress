import { useState } from 'react';
import { ArrowLeftRight, CheckCircle2, ShieldCheck, Scale, MessageSquare, Phone, Sparkles, Filter, Clock } from 'lucide-react';
import { HUB_TO_HUB_ROUTES, BUSINESS_INFO } from '../data/logisticsData';
import { HubToHubRoute } from '../types';

interface HubToHubSectionProps {
  onSelectCorridor?: (routeId: string) => void;
}

export default function HubToHubSection({ onSelectCorridor }: HubToHubSectionProps) {
  const [selectedState, setSelectedState] = useState<string>('all');

  const states = [
    { id: 'all', label: 'All Corridors (10)' },
    { id: 'Rajasthan', label: 'Rajasthan' },
    { id: 'Punjab & Haryana', label: 'Punjab & Haryana' },
    { id: 'Uttar Pradesh', label: 'Uttar Pradesh' }
  ];

  const filteredRoutes = selectedState === 'all'
    ? HUB_TO_HUB_ROUTES
    : HUB_TO_HUB_ROUTES.filter((r) => {
        if (selectedState === 'Punjab & Haryana') {
          return r.state === 'Punjab' || r.state === 'Haryana' || r.state === 'Punjab & Haryana';
        }
        return r.state === selectedState;
      });

  const handleBookRoute = (route: HubToHubRoute) => {
    const text = encodeURIComponent(
      `Hello Deliver Express, I want to book Both Side Hub to Hub Cargo for ${route.routeDisplay} at ₹${route.ratePerKg}/kg (Min weight ${route.minWeightKg} kg). Please advise on dispatch timing & hub drop-off.`
    );
    window.open(`https://wa.me/91${BUSINESS_INFO.whatsapp}?text=${text}`, '_blank', 'noopener,noreferrer');
  };

  const handleCalculateClick = (routeId: string) => {
    if (onSelectCorridor) {
      onSelectCorridor(routeId);
    }
    const el = document.getElementById('quote-calculator');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="hub-rates" className="py-16 sm:py-20 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-10">
          <span className="bg-orange-100 text-orange-700 px-4 py-1.5 rounded-md text-xs font-bold uppercase tracking-wider mb-3 inline-block">
            Both Side Hub to Hub Freight Network
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight font-heading">
            North India Hub to Hub Per-Kg Corridors
          </h2>
          <p className="mt-3 text-base text-slate-600">
            Dedicated commercial cargo lines operating bidirectionally (Delhi ⇄ City) with transparent per-kilogram billing. Minimum weight requirement applies per corridor, with unlimited maximum weight.
          </p>
        </div>

        {/* Feature Pills */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-10 max-w-4xl mx-auto">
          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-orange-100 text-orange-600 flex items-center justify-center shrink-0">
              <ArrowLeftRight className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-bold text-xs text-slate-900">Both Side Hub to Hub</h4>
              <p className="text-[11px] text-slate-500">Same rate in both directions (Delhi ⇄ Hub)</p>
            </div>
          </div>

          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-green-100 text-green-700 flex items-center justify-center shrink-0">
              <Scale className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-bold text-xs text-slate-900">Clear Min Weight Rule</h4>
              <p className="text-[11px] text-slate-500">50 kg (RJ/PB/HR) • 100 kg (UP Hubs)</p>
            </div>
          </div>

          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center shrink-0">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-bold text-xs text-slate-900">Unlimited Max Weight</h4>
              <p className="text-[11px] text-slate-500">From single cartons to multi-ton consignments</p>
            </div>
          </div>
        </div>

        {/* State Filter Buttons */}
        <div className="flex flex-wrap items-center justify-center gap-2 mb-8">
          {states.map((st) => (
            <button
              key={st.id}
              onClick={() => setSelectedState(st.id)}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                selectedState === st.id
                  ? 'bg-slate-900 text-white shadow-md'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              {st.label}
            </button>
          ))}
        </div>

        {/* Corridors Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredRoutes.map((route) => (
            <div
              key={route.id}
              className={`bg-white rounded-3xl border transition-all duration-200 p-6 flex flex-col justify-between relative overflow-hidden ${
                route.popular
                  ? 'border-orange-300 shadow-md ring-1 ring-orange-200'
                  : 'border-slate-200 shadow-sm hover:shadow-lg hover:border-slate-300'
              }`}
            >
              {/* Badge */}
              <div className="flex items-center justify-between gap-2 mb-4">
                <span className="inline-flex items-center gap-1.5 text-[10px] font-bold tracking-wider uppercase px-2.5 py-1 rounded-full bg-orange-50 text-orange-700 border border-orange-200">
                  <ArrowLeftRight className="w-3 h-3 text-orange-600" />
                  Both Side Hub to Hub
                </span>

                <span className="text-[10px] font-bold text-slate-500 bg-slate-100 px-2 py-0.5 rounded">
                  {route.state}
                </span>
              </div>

              {/* Route Title & Per Kg Rate */}
              <div>
                <h3 className="text-xl font-bold text-slate-900 font-heading flex items-center gap-2">
                  <span>{route.routeDisplay}</span>
                </h3>

                <div className="mt-3 flex items-baseline gap-2">
                  <span className="text-3xl font-extrabold text-orange-600 font-heading">
                    ₹{route.ratePerKg}
                  </span>
                  <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                    / Kg
                  </span>
                </div>

                <p className="text-xs text-slate-500 mt-1 font-medium">
                  {route.note}
                </p>

                {/* Specifics Box */}
                <div className="my-5 p-3.5 bg-slate-50 rounded-2xl border border-slate-100 space-y-2 text-xs">
                  <div className="flex justify-between items-center text-slate-700">
                    <span className="text-slate-500 font-medium">Minimum Weight:</span>
                    <span className="font-bold text-slate-900 bg-white px-2 py-0.5 rounded border border-slate-200">
                      {route.minWeightKg} Kg Minimum
                    </span>
                  </div>

                  <div className="flex justify-between items-center text-slate-700">
                    <span className="text-slate-500 font-medium">Maximum Weight:</span>
                    <span className="font-bold text-emerald-700">
                      Unlimited
                    </span>
                  </div>

                  <div className="flex justify-between items-center text-slate-700">
                    <span className="text-slate-500 font-medium">Transit Speed:</span>
                    <span className="font-semibold text-slate-800 flex items-center gap-1">
                      <Clock className="w-3 h-3 text-orange-500" />
                      {route.transitTime}
                    </span>
                  </div>

                  <div className="pt-2 border-t border-slate-200 text-slate-600">
                    <span className="text-[10px] uppercase font-bold text-slate-400 block mb-0.5">
                      Destination Hubs:
                    </span>
                    <span className="text-[11px] text-slate-700 leading-snug block">
                      {route.hubLocation}
                    </span>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-2 flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => handleCalculateClick(route.id)}
                  className="flex-1 py-2.5 px-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs text-center transition-colors"
                >
                  Calculate Cost
                </button>

                <button
                  type="button"
                  onClick={() => handleBookRoute(route)}
                  className="py-2.5 px-3 rounded-xl bg-green-600 hover:bg-green-700 text-white font-bold text-xs flex items-center gap-1.5 transition-colors shrink-0"
                  title="Book on WhatsApp"
                >
                  <MessageSquare className="w-3.5 h-3.5" />
                  <span>WhatsApp</span>
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Quick Rate Table Summary Card */}
        <div className="mt-12 bg-slate-900 text-white rounded-3xl p-6 sm:p-8 shadow-xl border border-slate-800">
          <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
            <div>
              <span className="text-xs uppercase font-bold tracking-wider text-orange-400">
                Summary Table
              </span>
              <h3 className="text-xl sm:text-2xl font-bold font-heading text-white mt-1">
                Both Side Hub-to-Hub Standard Tariff Sheet
              </h3>
              <p className="text-xs sm:text-sm text-slate-300 mt-2 max-w-2xl">
                All rates apply in both directions (Delhi to Destination & Destination to Delhi). Goods can be dropped off or picked up at partner warehouse hubs. Door pickup can be arranged on request.
              </p>
            </div>

            <a
              href={`tel:${BUSINESS_INFO.mobile}`}
              className="px-6 py-3.5 bg-orange-600 hover:bg-orange-700 text-white font-bold text-xs rounded-xl shadow-lg transition-transform active:scale-95 shrink-0 flex items-center gap-2"
            >
              <Phone className="w-4 h-4" />
              <span>Call Dispatch: {BUSINESS_INFO.mobileFormatted}</span>
            </a>
          </div>

          <div className="mt-8 overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 uppercase text-[10px] tracking-wider">
                  <th className="py-3 pr-4 font-bold">Corridor</th>
                  <th className="py-3 px-4 font-bold">Per Kg Rate</th>
                  <th className="py-3 px-4 font-bold">Min Weight Required</th>
                  <th className="py-3 px-4 font-bold">Max Weight</th>
                  <th className="py-3 px-4 font-bold">Directionality</th>
                  <th className="py-3 pl-4 font-bold text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-slate-200">
                {HUB_TO_HUB_ROUTES.map((route) => (
                  <tr key={route.id} className="hover:bg-slate-800/40 transition-colors">
                    <td className="py-3.5 pr-4 font-bold text-white flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-orange-500"></span>
                      {route.routeDisplay}
                    </td>
                    <td className="py-3.5 px-4 font-extrabold text-orange-400 text-sm">
                      ₹{route.ratePerKg} <span className="text-xs text-slate-400 font-normal">/ kg</span>
                    </td>
                    <td className="py-3.5 px-4 font-semibold text-slate-300">
                      {route.minWeightKg} Kg
                    </td>
                    <td className="py-3.5 px-4 text-emerald-400 font-medium">
                      Unlimited
                    </td>
                    <td className="py-3.5 px-4 text-slate-400">
                      <span className="inline-flex items-center gap-1 bg-slate-800 text-slate-300 px-2 py-0.5 rounded text-[10px]">
                        <ArrowLeftRight className="w-3 h-3 text-orange-400" />
                        Both Side Hub to Hub
                      </span>
                    </td>
                    <td className="py-3.5 pl-4 text-right">
                      <button
                        type="button"
                        onClick={() => handleCalculateClick(route.id)}
                        className="text-[11px] font-bold text-orange-400 hover:text-orange-300 underline underline-offset-2"
                      >
                        Calculate
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

      </div>
    </section>
  );
}
