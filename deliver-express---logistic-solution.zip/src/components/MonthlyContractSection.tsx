import { CalendarCheck, Shield, CheckCircle2, TrendingDown, Users, FileText, Phone, MessageSquare, ArrowRight } from 'lucide-react';
import { BUSINESS_INFO, VEHICLES } from '../data/logisticsData';

interface MonthlyContractSectionProps {
  onOpenBookingModal: (preselectedVehicle?: string, preselectedService?: string) => void;
}

export default function MonthlyContractSection({ onOpenBookingModal }: MonthlyContractSectionProps) {
  const benefits = [
    {
      title: 'Zero Capital Expenditure',
      desc: 'No need to buy vehicles or incur loan EMIs. Get commercial vehicles immediately operational.',
      icon: TrendingDown,
    },
    {
      title: 'Dedicated Commercial Driver',
      desc: 'Experienced, background-verified driver assigned specifically to your daily operations.',
      icon: Users,
    },
    {
      title: 'Zero Maintenance & Breakdown Stress',
      desc: 'We handle all tire changes, engine servicing, and offer immediate standby replacement vehicles.',
      icon: Shield,
    },
    {
      title: '100% Tax & GST Invoicing',
      desc: 'Monthly computerized billing with input tax credit (ITC) for seamless corporate accounting.',
      icon: FileText,
    },
  ];

  return (
    <section id="monthly-hire" className="py-16 sm:py-20 bg-slate-50 border-b border-slate-200 text-slate-900 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-10 relative">
        
        {/* Section Heading */}
        <div className="max-w-3xl mb-12">
          <span className="bg-orange-100 text-orange-700 px-4 py-1.5 rounded-md text-xs font-bold uppercase tracking-wider mb-3 inline-block">
            Corporate & Business Fleet Rental
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight font-heading">
            Fixed Monthly Basis Commercial Vehicles
          </h2>
          <p className="mt-3 text-base text-slate-600 leading-relaxed">
            Need a dedicated delivery vehicle every day for your factory, e-commerce warehouse, supermarket, or distribution route in Delhi NCR? Hire our dedicated fleet on fixed monthly contracts.
          </p>
        </div>

        {/* Benefits Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {benefits.map((item, idx) => {
            const Icon = item.icon;
            return (
              <div
                key={idx}
                className="bg-white border border-slate-200 rounded-3xl p-6 hover:shadow-xl hover:border-orange-200 transition-all duration-200"
              >
                <div className="w-10 h-10 rounded-xl bg-orange-50 text-orange-600 flex items-center justify-center mb-4">
                  <Icon className="w-5 h-5" />
                </div>
                <h3 className="text-base font-bold text-slate-900 mb-2 font-heading">
                  {item.title}
                </h3>
                <p className="text-xs text-slate-600 leading-relaxed">
                  {item.desc}
                </p>
              </div>
            );
          })}
        </div>

        {/* Monthly Fleet Options Table / Cards */}
        <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 shadow-sm">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-6 mb-6">
            <div>
              <h3 className="text-xl font-bold text-slate-900 font-heading">
                Monthly Contract Vehicles Available Immediately
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                Contracts include verified driver, scheduled maintenance, and replacement guarantee.
              </p>
            </div>
            <span className="inline-flex items-center gap-1.5 text-xs text-green-700 font-bold bg-green-50 px-3 py-1.5 rounded-lg border border-green-200">
              <CheckCircle2 className="w-4 h-4" /> Ready for Immediate Deployment
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4">
            {VEHICLES.map((vehicle) => (
              <div
                key={vehicle.id}
                className="bg-slate-50 border border-slate-200 rounded-2xl p-4 flex flex-col justify-between hover:border-orange-200 transition-colors"
              >
                <div>
                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
                    {vehicle.category}
                  </span>
                  <h4 className="text-sm font-bold text-slate-900 mt-1">
                    {vehicle.name}
                  </h4>
                  <div className="mt-2 text-xs text-slate-600">
                    <span className="text-slate-400">Capacity:</span> {vehicle.payloadCapacity}
                  </div>
                  <div className="mt-3 py-1.5 px-2 bg-orange-50 rounded border border-orange-200 text-orange-700 font-bold text-xs">
                    {vehicle.monthlyEstimate}
                  </div>
                </div>

                <button
                  onClick={() => onOpenBookingModal(vehicle.id, 'monthly_contract')}
                  className="mt-4 w-full py-2 px-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs transition-colors flex items-center justify-center gap-1"
                >
                  <span>Inquire Contract</span>
                  <ArrowRight className="w-3 h-3 text-orange-400" />
                </button>
              </div>
            ))}
          </div>

          {/* CTA Bar */}
          <div className="mt-8 pt-6 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="text-xs text-slate-600 text-center sm:text-left">
              Need custom terms, specific distance limits, or branded vehicle wrapping? Let's discuss.
            </div>

            <div className="flex items-center gap-3">
              <a
                href={`tel:${BUSINESS_INFO.mobile}`}
                className="py-2.5 px-4 rounded-xl bg-orange-600 hover:bg-orange-700 text-white font-bold text-xs flex items-center gap-1.5 shadow-sm transition-colors"
              >
                <Phone className="w-4 h-4" />
                <span>Call {BUSINESS_INFO.mobile}</span>
              </a>

              <a
                href={`https://wa.me/91${BUSINESS_INFO.whatsapp}?text=${encodeURIComponent(
                  'Hello Deliver Express, I need a fixed monthly basis vehicle on contract in Delhi NCR. Please share corporate package details.'
                )}`}
                target="_blank"
                rel="noopener noreferrer"
                className="py-2.5 px-4 rounded-xl bg-green-600 hover:bg-green-700 text-white font-bold text-xs flex items-center gap-1.5 transition-colors shadow-sm"
              >
                <MessageSquare className="w-4 h-4 fill-current" />
                <span>WhatsApp Details</span>
              </a>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
}
