import { Phone, MessageSquare, Zap } from 'lucide-react';
import { BUSINESS_INFO } from '../data/logisticsData';

interface MobileStickyBarProps {
  onOpenBookingModal: () => void;
}

export default function MobileStickyBar({ onOpenBookingModal }: MobileStickyBarProps) {
  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 lg:hidden bg-slate-950/95 backdrop-blur-md border-t border-slate-800 p-2.5 px-4 shadow-2xl">
      <div className="flex items-center gap-2 max-w-md mx-auto">
        <a
          id="sticky-mobile-call-btn"
          href={`tel:${BUSINESS_INFO.mobile}`}
          className="flex-1 py-3 px-3 rounded-xl bg-orange-600 hover:bg-orange-700 text-white font-extrabold text-xs flex items-center justify-center gap-1.5 shadow-md active:scale-95 transition-all"
        >
          <Phone className="w-4 h-4 fill-current" />
          <span>Call Now</span>
        </a>

        <a
          id="sticky-mobile-whatsapp-btn"
          href={`https://wa.me/91${BUSINESS_INFO.whatsapp}?text=${encodeURIComponent(
            'Hello Deliver Express, I need logistics transport in Delhi NCR. Please share vehicle rates.'
          )}`}
          target="_blank"
          rel="noopener noreferrer"
          className="flex-1 py-3 px-3 rounded-xl bg-green-600 hover:bg-green-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-md active:scale-95 transition-all"
        >
          <MessageSquare className="w-4 h-4 fill-current" />
          <span>WhatsApp</span>
        </a>

        <button
          id="sticky-mobile-quote-btn"
          onClick={onOpenBookingModal}
          className="p-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-orange-400 border border-slate-700 active:scale-95 transition-all"
          title="Instant Quote"
          aria-label="Instant Quote"
        >
          <Zap className="w-4 h-4 fill-current" />
        </button>
      </div>
    </div>
  );
}
