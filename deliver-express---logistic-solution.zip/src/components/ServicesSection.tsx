import { Zap, CalendarCheck, ShieldCheck, Layers, ArrowRight, CheckCircle2, MessageSquare, Phone, Scale } from 'lucide-react';
import { SERVICES, BUSINESS_INFO } from '../data/logisticsData';
import { ServiceType } from '../types';

interface ServicesSectionProps {
  onSelectService: (serviceId: ServiceType) => void;
}

export default function ServicesSection({ onSelectService }: ServicesSectionProps) {
  const getIcon = (id: ServiceType) => {
    switch (id) {
      case 'per_kg':
        return <Scale className="w-6 h-6 text-orange-600" />;
      case 'same_day':
        return <Zap className="w-6 h-6 text-orange-600" />;
      case 'monthly_contract':
        return <CalendarCheck className="w-6 h-6 text-orange-600" />;
      case 'full_truck':
        return <ShieldCheck className="w-6 h-6 text-slate-800" />;
      case 'part_truck':
        return <Layers className="w-6 h-6 text-orange-600" />;
    }
  };

  return (
    <section id="services" className="py-16 sm:py-20 bg-slate-50 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <span className="bg-orange-100 text-orange-700 px-4 py-1.5 rounded-md text-xs font-bold uppercase tracking-wider mb-3 inline-block">
            Cargo & Logistics Redefined
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight font-heading">
            Tailored Freight & Transport Services
          </h2>
          <p className="mt-3 text-base text-slate-600">
            From Both Side Hub to Hub freight starting at ₹9/kg across 10 North India corridors to dedicated commercial fleets on fixed monthly hire, Deliver Express provides end-to-end reliability.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {SERVICES.map((service) => (
            <div
              key={service.id}
              className={`bg-white rounded-3xl border border-slate-200 shadow-sm hover:shadow-xl hover:border-orange-200 transition-all duration-200 p-6 sm:p-8 flex flex-col justify-between group relative overflow-hidden ${
                service.id === 'per_kg' ? 'md:col-span-2 border-orange-200/90 shadow-md bg-gradient-to-br from-white via-white to-orange-50/20' : ''
              }`}
            >
              {/* Highlight ribbons */}
              {service.id === 'per_kg' && (
                <div className="absolute top-0 right-0 bg-orange-600 text-white text-[11px] font-bold px-4 py-1.5 rounded-bl-xl shadow-sm tracking-wide">
                  BOTH SIDE HUB TO HUB • 10 CORRIDORS FROM ₹9/KG
                </div>
              )}
              {service.id === 'monthly_contract' && (
                <div className="absolute top-0 right-0 bg-slate-900 text-white text-[11px] font-bold px-3.5 py-1.5 rounded-bl-xl">
                  Popular for Businesses
                </div>
              )}

              <div>
                <div className="flex items-center gap-4 mb-4">
                  <div className="w-12 h-12 rounded-xl bg-slate-100 flex items-center justify-center group-hover:bg-orange-50 transition-colors">
                    {getIcon(service.id)}
                  </div>
                  <div>
                    <span className="text-xs font-bold text-orange-600 uppercase tracking-wide">
                      {service.badge}
                    </span>
                    <h3 className="text-xl sm:text-2xl font-bold text-slate-900 font-heading">
                      {service.title}
                    </h3>
                  </div>
                </div>

                <p className="text-sm text-slate-600 leading-relaxed mb-5">
                  {service.fullDesc}
                </p>

                {/* Key Features List */}
                <div className={`space-y-2 mb-6 ${service.id === 'per_kg' ? 'grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-2 space-y-0' : ''}`}>
                  <p className={`text-xs font-bold text-slate-900 uppercase tracking-wider ${service.id === 'per_kg' ? 'sm:col-span-2' : ''}`}>
                    Key Highlights:
                  </p>
                  {service.features.map((feature, idx) => (
                    <div key={idx} className="flex items-start gap-2 text-xs text-slate-700">
                      <CheckCircle2 className="w-4 h-4 text-green-600 shrink-0 mt-0.5" />
                      <span className="font-medium">{feature}</span>
                    </div>
                  ))}
                </div>

                <div className="bg-slate-50 rounded-xl p-3 border border-slate-100 mb-6">
                  <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-1">
                    Recommended For:
                  </span>
                  <p className="text-xs text-slate-700 font-medium">
                    {service.idealFor}
                  </p>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-4 border-t border-slate-100 flex flex-wrap items-center gap-2.5">
                <button
                  onClick={() => onSelectService(service.id)}
                  className="flex-1 py-2.5 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-colors"
                >
                  <span>Book {service.title}</span>
                  <ArrowRight className="w-4 h-4 text-orange-400" />
                </button>

                <a
                  href={`https://wa.me/91${BUSINESS_INFO.whatsapp}?text=${encodeURIComponent(
                    service.id === 'per_kg'
                      ? `Hello Deliver Express, I need quotation for Both Side Hub to Hub Per Kg Cargo service (corridors starting at ₹9/kg, min weight 50kg/100kg, max unlimited).`
                      : `Hello Deliver Express, I want to inquire about ${service.title} in Delhi NCR.`
                  )}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="py-2.5 px-3.5 rounded-xl bg-green-50 hover:bg-green-100 text-green-700 border border-green-200 font-bold text-xs flex items-center gap-1.5 transition-colors"
                  title="WhatsApp inquiry"
                >
                  <MessageSquare className="w-4 h-4" />
                  <span className="hidden sm:inline">WhatsApp</span>
                </a>

                <a
                  href={`tel:${BUSINESS_INFO.mobile}`}
                  className="py-2.5 px-3.5 rounded-xl bg-orange-50 hover:bg-orange-100 text-orange-700 border border-orange-200 font-bold text-xs flex items-center gap-1.5 transition-colors"
                  title="Call for this service"
                >
                  <Phone className="w-4 h-4" />
                  <span className="hidden sm:inline">Call</span>
                </a>
              </div>

            </div>
          ))}
        </div>

      </div>
    </section>
  );
}
