import { Vehicle, ServiceDetail, HubToHubRoute } from '../types';

export const BUSINESS_INFO = {
  companyName: 'Deliver Express',
  title: 'Cargo & Logistics Redefined',
  tagline: 'Both Side Hub to Hub Cargo & Full Logistics Partner Across Delhi NCR & North India Corridors',
  mobile: '8851036573',
  mobileFormatted: '+91 8851036573',
  whatsapp: '8851036573',
  whatsappFormatted: '+91 8851036573',
  email: 'deliverexpressinfo@gmail.com',
  operatingRegion: 'Delhi NCR, Rajasthan (Jaipur & wider Rajasthan), Punjab & Haryana (Chandigarh, Mohali, Ambala, Ludhiana, Jalandhar), UP (Lucknow, Kanpur, Allahabad)',
  workingHours: '24/7 Operations & On-Demand Dispatch',
  officeAddress: 'Delhi NCR Hub: Near NH-48 / Ring Road Corridor, New Delhi & Gurugram Border',
};

export const VEHICLES: Vehicle[] = [
  {
    id: 'eeco',
    name: 'Maruti Suzuki Eeco',
    tagline: 'Compact Cargo Van for Rapid Intra-City Deliveries',
    category: 'Light Commercial',
    payloadCapacity: '500 - 600 Kg',
    payloadKg: 550,
    dimensions: '6.5 ft (L) x 4.5 ft (W) x 4.0 ft (H)',
    volumeCuFt: 'Approx. 100 cu. ft.',
    bestFor: [
      'E-commerce & retail parcel distribution',
      'Pharma & medical supplies',
      'Small carton boxes & consumer goods',
      'Tight city alleys & residential colonies'
    ],
    idealIndustries: ['Retailers', 'Online Sellers', 'Distributors', 'Courier Companies'],
    basePriceEstimate: 'Starting ₹499 / trip',
    monthlyEstimate: '₹28,000 - ₹34,000 / month',
    iconName: 'CarFront',
    popular: false,
  },
  {
    id: 'tata-ace',
    name: 'Tata Ace (Chhota Hathi)',
    tagline: 'The Undisputed King of Intra-NCR Goods Shifting',
    category: 'Light Commercial',
    payloadCapacity: '750 - 1,000 Kg (1 Ton)',
    payloadKg: 950,
    dimensions: '7.2 ft (L) x 4.8 ft (W) x 4.5 ft (H)',
    volumeCuFt: 'Approx. 150 cu. ft.',
    bestFor: [
      'FMCG daily distribution & Kirana supply',
      'Home appliance & furniture movement',
      'Light industrial spare parts',
      'Same day point-to-point dispatch'
    ],
    idealIndustries: ['FMCG Brands', 'Wholesalers', 'Furniture Stores', 'Appliance Dealers'],
    basePriceEstimate: 'Starting ₹699 / trip',
    monthlyEstimate: '₹34,000 - ₹42,000 / month',
    iconName: 'Truck',
    popular: true,
  },
  {
    id: 'bolero',
    name: 'Mahindra Bolero (Pickup / Maxi Truck)',
    tagline: 'Heavy-Duty Power for Rugged Cargo & Bulk Loads',
    category: 'Medium Commercial',
    payloadCapacity: '1.2 - 1.7 Tons (1,700 Kg)',
    payloadKg: 1500,
    dimensions: '8.5 ft (L) x 5.5 ft (W) x 5.0 ft (H)',
    volumeCuFt: 'Approx. 230 cu. ft.',
    bestFor: [
      'Hardware, steel, piping & sanitary goods',
      'Electrical cables & industrial machinery',
      'Vegetable / agricultural wholesale transport',
      'Construction equipment & heavy goods'
    ],
    idealIndustries: ['Industrial Fabricators', 'Hardware Traders', 'Building Materials', 'Contractors'],
    basePriceEstimate: 'Starting ₹999 / trip',
    monthlyEstimate: '₹42,000 - ₹52,000 / month',
    iconName: 'Truck',
    popular: false,
  },
  {
    id: 'canter-14',
    name: '14 Feet Canter',
    tagline: 'High Volume Medium Freight Truck for Commercial Loads',
    category: 'Heavy Canter',
    payloadCapacity: '3.5 - 4.0 Tons (4,000 Kg)',
    payloadKg: 3800,
    dimensions: '14 ft (L) x 6.5 ft (W) x 6.5 ft (H)',
    volumeCuFt: 'Approx. 590 cu. ft.',
    bestFor: [
      'Medium factory & warehouse stock relocation',
      'Textile rolls, garment exports & fabric bales',
      'Consumer durables & bulk palletized items',
      'Full & Part Truck Loading across NCR'
    ],
    idealIndustries: ['Warehouses', 'Garment Exporters', 'Automobile Ancillaries', 'Logistics 3PL'],
    basePriceEstimate: 'Starting ₹1,899 / trip',
    monthlyEstimate: '₹65,000 - ₹80,000 / month',
    iconName: 'Boxes',
    popular: true,
  },
  {
    id: 'canter-17',
    name: '17 Feet Canter',
    tagline: 'Maximum Volume Commercial Truck for Heavy Bulk Transport',
    category: 'Heavy Canter',
    payloadCapacity: '5.0 - 6.5 Tons (6,000 Kg)',
    payloadKg: 5500,
    dimensions: '17 ft (L) x 7.0 ft (W) x 7.0 ft (H)',
    volumeCuFt: 'Approx. 830 cu. ft.',
    bestFor: [
      'Full factory transfers & large machinery logistics',
      'Bulk FMCG master carton movement between hubs',
      'High-cube light-weight volume shipments',
      'Direct warehouse-to-warehouse cross-docking'
    ],
    idealIndustries: ['Manufacturing Units', 'Large E-Commerce Hubs', 'FMCG Conglomerates', 'Supply Chains'],
    basePriceEstimate: 'Starting ₹2,499 / trip',
    monthlyEstimate: '₹85,000 - ₹1,05,000 / month',
    iconName: 'Container',
    popular: false,
  },
];

export const SERVICES: ServiceDetail[] = [
  {
    id: 'per_kg',
    title: 'Per Kg Transportation',
    shortDesc: 'Both side hub-to-hub commercial cargo network starting at just ₹9 / kg.',
    fullDesc: 'Ship commercial goods with transparent per-kilogram billing across dedicated North India corridors. Rates apply equally in both directions (Delhi ⇄ Destination City, Both Side Hub to Hub). Minimum weight requirement is 50 kg or 100 kg depending on the destination, with unlimited maximum cargo weight.',
    badge: 'Both Side Hub to Hub from ₹9/kg',
    features: [
      'Delhi ⇄ Jaipur: ₹9 / kg (Min weight 50 kg)',
      'Delhi ⇄ Rajasthan: ₹17 / kg (Min weight 50 kg)',
      'Delhi ⇄ Mohali: ₹9 / kg (Min weight 50 kg)',
      'Delhi ⇄ Chandigarh: ₹9 / kg (Min weight 50 kg)',
      'Delhi ⇄ Ambala: ₹9 / kg (Min weight 50 kg)',
      'Delhi ⇄ Ludhiana: ₹12 / kg (Min weight 50 kg)',
      'Delhi ⇄ Jalandhar: ₹14 / kg (Min weight 50 kg)',
      'Delhi ⇄ Lucknow: ₹17 / kg (Min weight 100 kg)',
      'Delhi ⇄ Allahabad: ₹27 / kg (Min weight 100 kg)',
      'Delhi ⇄ Kanpur: ₹17 / kg (Min weight 100 kg)',
      'Both Side Hub to Hub: Identical rates in both directions',
      'Maximum cargo weight: Unlimited across all routes'
    ],
    icon: 'Scale',
    idealFor: 'Wholesalers, traders, textile merchants, industrial fabricators, carton freight, machinery spares.'
  },
  {
    id: 'same_day',
    title: 'Same Day Delivery',
    shortDesc: 'Direct point-to-point express freight dispatch across Delhi NCR within hours.',
    fullDesc: 'Need urgent dispatch of raw materials, retail cartons, or stock replenishments? Our on-demand intra-city fleet ensures prompt driver dispatch and dedicated point-to-point delivery across Delhi, Gurgaon, Noida, Faridabad, and Ghaziabad.',
    badge: 'Intra-NCR Express Dispatch',
    features: [
      'Prompt driver dispatch and pickup coordination',
      'Dedicated direct transit with zero co-loading delays',
      'Real-time coordination via WhatsApp & phone',
      'Door-to-door ground loading assistance options',
      'Proof of delivery (POD) on completion'
    ],
    icon: 'Zap',
    idealFor: 'Urgent factory orders, retail restocks, urgent B2B shipments, e-commerce consignments.'
  },
  {
    id: 'monthly_contract',
    title: 'Fix Monthly Basis Vehicle Available',
    shortDesc: 'Dedicated commercial vehicles with experienced drivers on flexible monthly contracts.',
    fullDesc: 'Eliminate the cost of vehicle purchase, insurance, permits, and driver management. Rent our well-maintained Eeco, Tata Ace, Bolero, 14ft or 17ft Canter on a predictable monthly retainer with guaranteed vehicle replacement during service maintenance.',
    badge: 'Corporate & Distributor Choice',
    features: [
      'Dedicated vehicle & vetted commercial driver',
      'Zero maintenance, repair, or tax liabilities',
      'Guaranteed replacement vehicle on routine service days',
      'Customized multi-point daily delivery route planning',
      'Transparent GST billing and corporate credit terms'
    ],
    icon: 'CalendarCheck',
    idealFor: 'E-commerce warehouses, FMCG distributors, garment factories, retail store chains, supermarket restocking.'
  },
  {
    id: 'full_truck',
    title: 'Full Truck Loading (FTL)',
    shortDesc: 'Exclusive dedicated truck for high-volume, bulk, or sensitive industrial consignments.',
    fullDesc: 'When your goods require an entire vehicle without any consolidation or intermediate offloading, Deliver Express FTL provides safe, dedicated carriage directly from your facility gate to the destination dock.',
    badge: 'Direct Point-to-Point Transport',
    features: [
      '100% capacity exclusively reserved for your cargo',
      'No multi-stop routing or secondary transshipments',
      'Sealed cargo transport with maximum security',
      'Available across all vehicle sizes (Tata Ace to 17ft Canter)',
      'Flexible loading and unloading time buffers'
    ],
    icon: 'ShieldCheck',
    idealFor: 'Heavy manufacturing units, bulk industrial machinery, high-value electronics, full warehouse stock relocation.'
  },
  {
    id: 'part_truck',
    title: 'Part Truck Loading (PTL)',
    shortDesc: 'Cost-efficient shared cargo service for small-to-medium size shipments.',
    fullDesc: 'Don’t pay for an entire truck when you only have a few pallets, cartons, or crates. Our Part Truck Loading service aggregates cargo heading along key Delhi NCR corridors, providing full-truck safety at fractional pricing.',
    badge: 'Economical Shared Transport',
    features: [
      'Pay strictly for the weight or volume your cargo occupies',
      'Frequent daily departures across major NCR industrial belts',
      'Carefully segregated cargo handling to prevent damage',
      'Ideal for regular partial consignments',
      'Substantial cost savings over single-vehicle hires'
    ],
    icon: 'Layers',
    idealFor: 'Small business traders, occasional shippers, trial shipments, sub-tonnage pallet freight.'
  }
];

export const NCR_HUBS = [
  {
    region: 'Delhi',
    areas: ['Okhla Industrial Area (Ph 1, 2, 3)', 'Mayapuri Industrial Area', 'Bawana & Narela Industrial Estate', 'Kirti Nagar & Naraina', 'Patparganj & Jhilmil', 'Kashmere Gate & Sadar Bazar', 'Mangolpuri & Nangloi']
  },
  {
    region: 'Gurugram & Manesar',
    areas: ['Udyog Vihar (Ph 1 to 5)', 'IMT Manesar (Ph 1 to 4)', 'Pace City 1 & 2', 'Sector 18 & 37 Industrial Zones', 'Cyber City & Golf Course Road Hubs']
  },
  {
    region: 'Noida & Greater Noida',
    areas: ['Noida Sector 62, 63, 65, 80 & 85', 'Noida Special Economic Zone (NSEZ)', 'Greater Noida Ecotech & Kasna', 'Surajpur Industrial Area', 'Knowledge Park Hubs']
  },
  {
    region: 'Faridabad & Ballabgarh',
    areas: ['Faridabad Industrial Area (Sec 24, 25, 31, 58)', 'NIT Faridabad Commercial Hub', 'Ballabgarh Industrial Corridor', 'Prithla & Sikri industrial belt']
  },
  {
    region: 'Ghaziabad & Sahibabad',
    areas: ['Sahibabad Industrial Area', 'Tronica City (Loni)', 'Mohan Nagar & Bulandshahr Road', 'Kavi Nagar & Meerut Road Industrial Area']
  }
];

export const WHY_CHOOSE_US = [
  {
    title: 'Prompt Fleet Dispatch',
    description: 'Strategically positioned fleet hubs across Delhi NCR and intercity corridors ensure swift pickup and on-time transit.',
    icon: 'Clock'
  },
  {
    title: 'Fix Monthly Rentals Available',
    description: 'Hassle-free corporate vehicle contracts with drivers, fuel management, and zero maintenance stress.',
    icon: 'Calendar'
  },
  {
    title: 'Verified Commercial Fleet',
    description: 'Clean, fully fitness-tested vehicles ranging from nimble Eeco to heavy 17 Feet Canters.',
    icon: 'CheckCircle2'
  },
  {
    title: 'Transparent Fair Rates',
    description: 'No surprise surge fees or hidden toll markups. Clear trip and monthly contract pricing.',
    icon: 'BadgePercent'
  },
  {
    title: 'Experienced Drivers',
    description: 'Police-verified, courteous commercial drivers well-versed with every Delhi NCR industrial corridor and MCD routes.',
    icon: 'UserCheck'
  },
  {
    title: 'Direct WhatsApp & Phone Support',
    description: 'Talk to human dispatch coordinators instantly on 8851036573 for real-time status updates.',
    icon: 'PhoneCall'
  }
];

export const HUB_TO_HUB_ROUTES: HubToHubRoute[] = [
  {
    id: 'delhi-jaipur',
    city: 'Jaipur',
    state: 'Rajasthan',
    routeDisplay: 'Delhi ⇄ Jaipur',
    ratePerKg: 9,
    minWeightKg: 50,
    maxWeightDisplay: 'Unlimited',
    transitTime: 'Next Day Delivery',
    bothWays: true,
    hubLocation: 'Vishwakarma / Sitapura / Transport Nagar Hubs',
    popular: true,
    note: 'Both side hub to hub • Daily scheduled departures'
  },
  {
    id: 'delhi-rajasthan',
    city: 'Rajasthan (Wider Network)',
    state: 'Rajasthan',
    routeDisplay: 'Delhi ⇄ Rajasthan',
    ratePerKg: 17,
    minWeightKg: 50,
    maxWeightDisplay: 'Unlimited',
    transitTime: '24 - 48 Hours',
    bothWays: true,
    hubLocation: 'Ajmer, Jodhpur, Kota, Bikaner, Udaipur Hubs',
    popular: false,
    note: 'Both side hub to hub • Comprehensive Rajasthan cargo network'
  },
  {
    id: 'delhi-mohali',
    city: 'Mohali',
    state: 'Punjab',
    routeDisplay: 'Delhi ⇄ Mohali',
    ratePerKg: 9,
    minWeightKg: 50,
    maxWeightDisplay: 'Unlimited',
    transitTime: 'Next Day Delivery',
    bothWays: true,
    hubLocation: 'Phase 7, 8 & 9 Industrial Area, SAS Nagar',
    popular: true,
    note: 'Both side hub to hub • Direct industrial transit'
  },
  {
    id: 'delhi-chandigarh',
    city: 'Chandigarh',
    state: 'Punjab & Haryana',
    routeDisplay: 'Delhi ⇄ Chandigarh',
    ratePerKg: 9,
    minWeightKg: 50,
    maxWeightDisplay: 'Unlimited',
    transitTime: 'Next Day Delivery',
    bothWays: true,
    hubLocation: 'Industrial Area Phase 1 & 2',
    popular: true,
    note: 'Both side hub to hub • High frequency linehaul'
  },
  {
    id: 'delhi-ambala',
    city: 'Ambala',
    state: 'Haryana',
    routeDisplay: 'Delhi ⇄ Ambala',
    ratePerKg: 9,
    minWeightKg: 50,
    maxWeightDisplay: 'Unlimited',
    transitTime: 'Next Day Delivery',
    bothWays: true,
    hubLocation: 'Ambala Cantt & City Wholesale Hubs',
    popular: false,
    note: 'Both side hub to hub • GT Road industrial corridor'
  },
  {
    id: 'delhi-ludhiana',
    city: 'Ludhiana',
    state: 'Punjab',
    routeDisplay: 'Delhi ⇄ Ludhiana',
    ratePerKg: 12,
    minWeightKg: 50,
    maxWeightDisplay: 'Unlimited',
    transitTime: 'Next Day Delivery',
    bothWays: true,
    hubLocation: 'Focal Point, Transport Nagar & Industrial Area A/B',
    popular: true,
    note: 'Both side hub to hub • Textile, cycle & manufacturing lane'
  },
  {
    id: 'delhi-jalandhar',
    city: 'Jalandhar',
    state: 'Punjab',
    routeDisplay: 'Delhi ⇄ Jalandhar',
    ratePerKg: 14,
    minWeightKg: 50,
    maxWeightDisplay: 'Unlimited',
    transitTime: '24 - 36 Hours',
    bothWays: true,
    hubLocation: 'Focal Point & Sports Goods Complex',
    popular: false,
    note: 'Both side hub to hub • Reliable industrial link'
  },
  {
    id: 'delhi-lucknow',
    city: 'Lucknow',
    state: 'Uttar Pradesh',
    routeDisplay: 'Delhi ⇄ Lucknow',
    ratePerKg: 17,
    minWeightKg: 100,
    maxWeightDisplay: 'Unlimited',
    transitTime: '24 - 36 Hours',
    bothWays: true,
    hubLocation: 'Transport Nagar, Nadarganj & Talkatora Industrial Area',
    popular: true,
    note: 'Both side hub to hub • Expressway fast corridor'
  },
  {
    id: 'delhi-allahabad',
    city: 'Allahabad (Prayagraj)',
    state: 'Uttar Pradesh',
    routeDisplay: 'Delhi ⇄ Allahabad',
    ratePerKg: 27,
    minWeightKg: 100,
    maxWeightDisplay: 'Unlimited',
    transitTime: '36 - 48 Hours',
    bothWays: true,
    hubLocation: 'Naini Industrial Area & Transport Nagar',
    popular: false,
    note: 'Both side hub to hub • Secure long-distance freight'
  },
  {
    id: 'delhi-kanpur',
    city: 'Kanpur',
    state: 'Uttar Pradesh',
    routeDisplay: 'Delhi ⇄ Kanpur',
    ratePerKg: 17,
    minWeightKg: 100,
    maxWeightDisplay: 'Unlimited',
    transitTime: '24 - 36 Hours',
    bothWays: true,
    hubLocation: 'Panki, Fazalganj, Dada Nagar & Transport Nagar',
    popular: true,
    note: 'Both side hub to hub • Heavy commercial & leather hub'
  }
];

