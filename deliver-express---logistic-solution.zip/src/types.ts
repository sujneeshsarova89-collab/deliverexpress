export type ServiceType = 
  | 'per_kg'
  | 'same_day' 
  | 'monthly_contract' 
  | 'full_truck' 
  | 'part_truck';

export interface Vehicle {
  id: string;
  name: string;
  tagline: string;
  category: 'Light Commercial' | 'Medium Commercial' | 'Heavy Canter';
  payloadCapacity: string;
  payloadKg: number;
  dimensions: string;
  volumeCuFt: string;
  bestFor: string[];
  idealIndustries: string[];
  basePriceEstimate: string;
  monthlyEstimate: string;
  iconName: string;
  popular?: boolean;
}

export interface ServiceDetail {
  id: ServiceType;
  title: string;
  shortDesc: string;
  fullDesc: string;
  badge: string;
  features: string[];
  icon: string;
  idealFor: string;
}

export interface HubToHubRoute {
  id: string;
  city: string;
  state: 'Rajasthan' | 'Punjab' | 'Haryana' | 'Punjab & Haryana' | 'Uttar Pradesh';
  routeDisplay: string;
  ratePerKg: number;
  minWeightKg: number;
  maxWeightDisplay: string;
  transitTime: string;
  bothWays: boolean;
  hubLocation: string;
  popular?: boolean;
  note?: string;
}

export interface QuoteRequest {
  vehicleId: string;
  serviceType: ServiceType;
  pickupLocation: string;
  dropLocation: string;
  cargoType: string;
  estimatedWeight: string;
  contactName: string;
  contactPhone: string;
  additionalNotes?: string;
}
