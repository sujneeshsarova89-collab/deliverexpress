import { useState } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import ServicesSection from './components/ServicesSection';
import HubToHubSection from './components/HubToHubSection';
import FleetSection from './components/FleetSection';
import MonthlyContractSection from './components/MonthlyContractSection';
import QuoteCalculator from './components/QuoteCalculator';
import DelhiNCRCoverage from './components/DelhiNCRCoverage';
import WhyChooseUs from './components/WhyChooseUs';
import ContactSection from './components/ContactSection';
import Footer from './components/Footer';
import BookingModal from './components/BookingModal';
import MobileStickyBar from './components/MobileStickyBar';
import { ServiceType } from './types';

export default function App() {
  const [modalOpen, setModalOpen] = useState(false);
  const [selectedVehicle, setSelectedVehicle] = useState<string | undefined>();
  const [selectedService, setSelectedService] = useState<string | undefined>();
  const [selectedCorridor, setSelectedCorridor] = useState<string | undefined>('delhi-jaipur');

  const handleOpenBookingModal = (preVehicle?: string, preService?: string) => {
    setSelectedVehicle(preVehicle);
    setSelectedService(preService);
    setModalOpen(true);
  };

  const handleBookVehicle = (vehicleId: string) => {
    setSelectedVehicle(vehicleId);
    setSelectedService('same_day');
    setModalOpen(true);
  };

  const handleSelectService = (serviceId: ServiceType) => {
    setSelectedService(serviceId);
    setModalOpen(true);
  };

  const handleSelectCorridor = (corridorId: string) => {
    setSelectedCorridor(corridorId);
    const element = document.getElementById('quote-calculator');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900 selection:bg-amber-500 selection:text-slate-950">
      {/* Top sticky header */}
      <Header onOpenBookingModal={handleOpenBookingModal} />

      {/* Main Content Sections */}
      <main className="flex-1">
        <Hero onOpenBookingModal={handleOpenBookingModal} />
        
        <ServicesSection onSelectService={handleSelectService} />

        <HubToHubSection onSelectCorridor={handleSelectCorridor} />
        
        <FleetSection onBookVehicle={handleBookVehicle} />
        
        <MonthlyContractSection onOpenBookingModal={handleOpenBookingModal} />
        
        <QuoteCalculator initialCorridorId={selectedCorridor} />
        
        <DelhiNCRCoverage />
        
        <WhyChooseUs />
        
        <ContactSection />
      </main>

      {/* Footer */}
      <Footer />

      {/* Floating Sticky Actions for Mobile Devices */}
      <MobileStickyBar onOpenBookingModal={() => handleOpenBookingModal()} />

      {/* Booking & Inquiry Modal */}
      <BookingModal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        preselectedVehicle={selectedVehicle}
        preselectedService={selectedService}
      />
    </div>
  );
}
