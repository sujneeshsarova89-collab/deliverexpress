import { BUSINESS_INFO } from '../data/logisticsData';

export function createWhatsAppUrl(params: {
  vehicleName?: string;
  serviceName?: string;
  pickup?: string;
  drop?: string;
  customMessage?: string;
}): string {
  const phone = BUSINESS_INFO.whatsapp;
  let text = `Hello Deliver Express Logistic Solution! 🚚\n\nI need logistics assistance in Delhi NCR:\n`;

  if (params.serviceName) {
    text += `• Service Required: ${params.serviceName}\n`;
  }
  if (params.vehicleName) {
    text += `• Vehicle Preferred: ${params.vehicleName}\n`;
  }
  if (params.pickup) {
    text += `• Pickup Location: ${params.pickup}\n`;
  }
  if (params.drop) {
    text += `• Drop Location: ${params.drop}\n`;
  }
  if (params.customMessage) {
    text += `• Details: ${params.customMessage}\n`;
  }

  text += `\nPlease provide rate quote and availability. Thank you!`;

  return `https://wa.me/91${phone}?text=${encodeURIComponent(text)}`;
}

export function createQuickWhatsAppUrl(note: string = 'Inquiry about logistics and vehicle booking'): string {
  const phone = BUSINESS_INFO.whatsapp;
  const text = `Hello Deliver Express Logistic Solution, I am inquiring regarding ${note}. Please share rates and details.`;
  return `https://wa.me/91${phone}?text=${encodeURIComponent(text)}`;
}
